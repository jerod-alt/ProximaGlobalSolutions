export const BOOK_URL =
  "https://calendly.com/jerod-proximaglobalsolutions/new-meeting";

export const CONTACT = {
  email: "Jerod@jgbposervices.com",
  phone: "+1 (956) 706-2193",
  linkedin: "https://www.linkedin.com/in/jerod-gonzales-0827283b2/",
};

export interface Service {
  num: string;
  title: string;
  category: string;
  desc: string;
  tags: string[];
}

export const SERVICES: Service[] = [
  { num: "01", title: "Executive Assistant", category: "Administrative", desc: "High-trust support for leaders who need their time back.", tags: ["executive assistant", "ea", "calendar", "email", "admin"] },
  { num: "02", title: "General Virtual Assistant", category: "Administrative", desc: "Day-to-day admin handled by a dedicated, reliable VA.", tags: ["virtual assistant", "general va", "admin", "support"] },
  { num: "03", title: "Operations Manager VA", category: "Administrative", desc: "Senior support overseeing processes, people, and delivery.", tags: ["operations manager", "ops va", "management", "admin"] },
  { num: "04", title: "Calendar & Email Management", category: "Administrative", desc: "Inboxes triaged and diaries kept clear and current.", tags: ["calendar", "email", "scheduling", "inbox"] },
  { num: "05", title: "Personal Assistant", category: "Administrative", desc: "Dedicated support for scheduling, research, and personal admin.", tags: ["personal assistant", "pa", "admin", "scheduling"] },
  { num: "06", title: "Sales Virtual Assistant", category: "Sales", desc: "Pipeline groundwork, CRM hygiene, and timely follow-ups.", tags: ["sales va", "crm", "pipeline", "follow up"] },
  { num: "07", title: "Lead Generation", category: "Sales", desc: "Researched, qualified prospects that feed your closers.", tags: ["lead generation", "prospecting", "outbound", "leads"] },
  { num: "08", title: "Appointment Setter", category: "Sales", desc: "Booked, confirmed meetings straight onto your calendar.", tags: ["appointment setter", "booking", "outreach", "sales"] },
  { num: "09", title: "CRM & Pipeline Management", category: "Sales", desc: "Clean data and a pipeline you can actually trust.", tags: ["crm", "pipeline", "hubspot", "salesforce"] },
  { num: "10", title: "Cold Outreach & Customer Follow-up", category: "Sales", desc: "Targeted outreach and follow-up sequences that convert.", tags: ["cold outreach", "follow up", "email", "sales"] },
  { num: "11", title: "Junior Accountant", category: "Accounting & Finance", desc: "Day-to-day bookkeeping and accounting support.", tags: ["junior accountant", "bookkeeping", "accounting"] },
  { num: "12", title: "Senior Accountant", category: "Accounting & Finance", desc: "Reconciliations, reporting, and month-end close.", tags: ["senior accountant", "reconciliation", "reporting", "close"] },
  { num: "13", title: "Accounts Receivable", category: "Accounting & Finance", desc: "Invoicing, collections, and AR ledgers kept current.", tags: ["accounts receivable", "ar", "invoicing", "collections"] },
  { num: "14", title: "Accounts Payable", category: "Accounting & Finance", desc: "Bills, vendor payments, and AP records managed end to end.", tags: ["accounts payable", "ap", "bills", "vendors"] },
  { num: "15", title: "Bookkeeping & Payroll", category: "Accounting & Finance", desc: "Books kept clean and payroll run on time.", tags: ["bookkeeping", "payroll", "finance", "ledger"] },
  { num: "16", title: "Financial Reporting & Analysis", category: "Accounting & Finance", desc: "Clear financial reports that inform better decisions.", tags: ["financial reporting", "analysis", "finance", "reporting"] },
  { num: "17", title: "Data Entry", category: "Data & Back Office", desc: "Accurate, reliable data entry handled off your plate.", tags: ["data entry", "processing", "records", "admin"] },
  { num: "18", title: "Data Processing & Verification", category: "Data & Back Office", desc: "Clean, verified data you can build decisions on.", tags: ["data processing", "verification", "quality", "data"] },
  { num: "19", title: "Database Management", category: "Data & Back Office", desc: "Records kept structured, current, and searchable.", tags: ["database", "records", "management", "data"] },
  { num: "20", title: "Research & Reporting", category: "Data & Back Office", desc: "Desk research and reports prepared to brief.", tags: ["research", "reporting", "analysis", "back office"] },
  { num: "21", title: "Email & Chat Support", category: "Customer Support", desc: "Responsive, on-brand support across written channels.", tags: ["email support", "live chat", "customer", "helpdesk"] },
  { num: "22", title: "Phone Support", category: "Customer Support", desc: "Friendly, professional voice support for your customers.", tags: ["phone support", "call", "inbound", "customer"] },
  { num: "23", title: "Customer Success", category: "Customer Support", desc: "Proactive support that keeps customers around.", tags: ["customer success", "retention", "onboarding", "support"] },
  { num: "24", title: "Help Desk / Technical Support", category: "Customer Support", desc: "Tier-1 technical support and ticket triage.", tags: ["help desk", "technical support", "tickets", "it"] },
  { num: "25", title: "Business Operations Specialist", category: "Operations", desc: "Hands-on support running your operational workflows.", tags: ["business operations", "ops", "workflow", "specialist"] },
  { num: "26", title: "Project Coordination", category: "Operations", desc: "Tasks, timelines, and stakeholders kept on track.", tags: ["project coordination", "pmo", "timeline", "admin"] },
  { num: "27", title: "SOP & Workflow Management", category: "Operations", desc: "Documented processes that scale with your team.", tags: ["sop", "workflow", "process", "documentation"] },
  { num: "28", title: "Vendor & Client Onboarding", category: "Operations", desc: "Smooth onboarding for new vendors and clients.", tags: ["onboarding", "vendor management", "client", "operations"] },
  { num: "29", title: "HVAC Coordinator", category: "HVAC", desc: "Dispatch, scheduling, and admin support for HVAC teams.", tags: ["hvac coordinator", "dispatch", "scheduling", "trades"] },
  { num: "30", title: "HVAC Dispatcher", category: "HVAC", desc: "Technicians routed and jobs sequenced efficiently.", tags: ["hvac dispatcher", "dispatch", "routing", "field service"] },
  { num: "31", title: "Technician Scheduling", category: "HVAC", desc: "Calendars and service calls kept full and on time.", tags: ["scheduling", "technician", "service", "hvac"] },
  { num: "32", title: "Work Order Management", category: "HVAC", desc: "Work orders created, tracked, and closed out.", tags: ["work order", "field service", "tracking", "hvac"] },
  { num: "33", title: "Solar Coordinator", category: "Solar", desc: "Project coordination and admin for solar installers.", tags: ["solar coordinator", "solar", "project", "installers"] },
  { num: "34", title: "Solar Appointment Setter", category: "Solar", desc: "Qualified solar consults booked onto your calendar.", tags: ["solar", "appointment setter", "booking", "sales"] },
  { num: "35", title: "Permit & Interconnection Support", category: "Solar", desc: "Permits and utility interconnection paperwork handled.", tags: ["permit", "interconnection", "utility", "solar"] },
  { num: "36", title: "Solar Project Scheduling", category: "Solar", desc: "Installs and site visits sequenced and confirmed.", tags: ["project scheduling", "solar", "install", "coordination"] },
  { num: "37", title: "AI Workflow Automation", category: "AI & Automation", desc: "Repetitive work automated end to end across your stack.", tags: ["ai automation", "workflow", "automation", "ai"] },
  { num: "38", title: "CRM & Document Automation", category: "AI & Automation", desc: "Proposals, invoices, and CRM updates that run themselves.", tags: ["crm automation", "document automation", "invoice", "proposal"] },
  { num: "39", title: "AI Chatbots & Voice Agents", category: "AI & Automation", desc: "AI agents that handle support and qualify leads 24/7.", tags: ["ai chatbot", "voice agent", "ai customer service", "support"] },
  { num: "40", title: "Zapier / Make / Power Automate", category: "AI & Automation", desc: "Your tools connected with no-code automation and APIs.", tags: ["zapier", "make", "power automate", "integration"] },
  { num: "41", title: "Power BI Dashboards", category: "Business Intelligence", desc: "Live dashboards that turn data into decisions.", tags: ["power bi", "dashboard", "bi", "analytics"] },
  { num: "42", title: "KPI & Reporting Automation", category: "Business Intelligence", desc: "KPIs tracked and reports delivered automatically.", tags: ["kpi", "reporting", "automation", "analytics"] },
  { num: "43", title: "Data Visualization", category: "Business Intelligence", desc: "Clear visuals that make the numbers obvious.", tags: ["data visualization", "charts", "reporting", "bi"] },
];

export const SERVICE_CATEGORIES = [
  "All",
  "Administrative",
  "Sales",
  "Accounting & Finance",
  "Data & Back Office",
  "Customer Support",
  "Operations",
  "HVAC",
  "Solar",
  "AI & Automation",
  "Business Intelligence",
];

export const POPULAR_SEARCHES = [
  "Executive Assistant",
  "Bookkeeping",
  "HVAC Coordinator",
  "AI Automation",
  "Lead Generation",
];

export const INDUSTRIES = [
  { num: "/01", name: "Construction", tag: "General · HVAC · Engineering" },
  { num: "/02", name: "HVAC", tag: "Field service · Dispatch · Admin" },
  { num: "/03", name: "Solar", tag: "Installation · Permits · Sales" },
  { num: "/04", name: "Accounting & Finance", tag: "Firms · Bookkeeping" },
  { num: "/05", name: "Healthcare", tag: "Clinics · Practices · Care" },
  { num: "/06", name: "Legal", tag: "Firms · Paralegals · Admin" },
  { num: "/07", name: "Real Estate", tag: "Property · REITs · Agents" },
  { num: "/08", name: "Technology & Consulting", tag: "Software · Advisory" },
  { num: "/09", name: "Logistics", tag: "Freight · Supply chain" },
  { num: "/10", name: "Marketing", tag: "Agencies · Creative studios" },
  { num: "/11", name: "Retail", tag: "E-commerce · Operations" },
  { num: "/12", name: "Professional Services", tag: "Consulting · Admin" },
];

export const PILLARS = [
  {
    icon: "◆",
    title: "Seamless integration",
    desc: "Professionals who work in your tools, processes, and hours.",
  },
  {
    icon: "⟶",
    title: "Senior focus",
    desc: "Offload admin and overflow so your people do high-value work.",
  },
  {
    icon: "◇",
    title: "Cost-effective scale",
    desc: "Grow capacity without growing overhead.",
  },
  {
    icon: "⬡",
    title: "True partnership",
    desc: "Excellence, partnership, and growth — the values we run on.",
  },
];

export const STEPS = [
  { num: "01", title: "Discover", desc: "We learn your workflows, tools, and goals." },
  { num: "02", title: "Match", desc: "We select professionals who fit your team and tasks." },
  { num: "03", title: "Onboard", desc: "They integrate into your processes and working hours." },
  { num: "04", title: "Scale", desc: "Add capacity as your needs grow." },
];

export const CASE_STUDIES = [
  {
    tag: "SaaS · Interior Design Tech",
    title: "Foyr",
    desc: "Ongoing virtual staffing — including a dedicated full-time QA professional embedded with their product team.",
    stat: "Active",
    statLabel: "Engagement",
    img: "/case1.png",
  },
  {
    tag: "Growth & Operations",
    title: "Build 10x",
    desc: "Embedded support helping the team scale operations and free up senior time for high-leverage work.",
    stat: "Active",
    statLabel: "Engagement",
    img: "/case2.png",
  },
  {
    tag: "Performing Arts",
    title: "Flashdance Performing Arts",
    desc: "Administrative and back-office support for day-to-day studio operations.",
    stat: "Served",
    statLabel: "Engagement",
    img: "/case3.png",
  },
];

export const METRICS = [
  { value: "—", label: "Clients supported" },
  { value: "—", label: "Professionals placed" },
  { value: "—", label: "Hours saved / week" },
  { value: "4", label: "Countries served" },
];

export const TESTIMONIALS = [
  {
    quote: "[ Add a verified quote from the Foyr team ]",
    name: "Foyr",
    role: "SaaS · Interior Design Technology",
    avatar: "/face1.png",
  },
  {
    quote: "[ Add a verified quote from the Build 10x team ]",
    name: "Build 10x",
    role: "Growth & Operations",
    avatar: "/face2.png",
  },
  {
    quote: "[ Add a verified quote from Flashdance Performing Arts ]",
    name: "Flashdance Performing Arts",
    role: "Performing Arts",
    avatar: "/face3.png",
  },
];

export const FAQ_ITEMS = [
  {
    q: "What does Proxima Global Solutions do?",
    a: "We provide dedicated offshore professionals across four areas: remote workforce solutions, business process outsourcing, virtual assistant services, and customer & sales support.",
  },
  {
    q: "How do your professionals work with our team?",
    a: "They integrate directly into your tools, processes, and working hours — operating as a seamless extension of your existing team rather than an outside vendor.",
  },
  {
    q: "What kind of tasks can you take on?",
    a: "Scheduling, data entry, bookkeeping overflow, back-office and administrative work, plus customer and sales support — freeing your senior people to focus on high-value work.",
  },
  {
    q: "How does pricing work?",
    a: "Roles typically range $1,000–$2,000 per month depending on the role, scope, and seniority. Book a 20-minute call and we'll tailor a plan to your specific needs.",
  },
  {
    q: "How quickly can we get started?",
    a: "Book a 20-minute intro call and we'll map out next steps — happy to go at your pace.",
  },
  {
    q: "Which countries do you serve?",
    a: "We currently serve businesses across the United States, Canada, United Kingdom, and Australia.",
  },
];

export const INSIGHTS = [
  {
    meta: "Insight · Placeholder",
    title: "Article headline goes here — replace with your first insight post",
    img: "/insight1.png",
  },
  {
    meta: "Insight · Placeholder",
    title: "Article headline goes here — replace with your second insight post",
    img: "/insight2.png",
  },
  {
    meta: "Insight · Placeholder",
    title: "Article headline goes here — replace with your third insight post",
    img: "/insight3.png",
  },
];

export const LOGOS = ["Foyr", "Build 10x", "Flashdance Performing Arts"];

export const FOOTER_COLS: { title: string; links: { label: string; href: string }[] }[] = [
  {
    title: "Company",
    links: [
      { label: "About", href: "/about" },
      { label: "Careers", href: "/careers" },
      { label: "Insights", href: "/#insights" },
      { label: "Contact", href: "/contact" },
    ],
  },
  {
    title: "Services",
    links: [
      { label: "Remote Workforce", href: "/services" },
      { label: "Business Process Outsourcing", href: "/services" },
      { label: "Virtual Assistants", href: "/services" },
      { label: "Customer & Sales", href: "/services" },
      { label: "AI & Automation", href: "/services" },
    ],
  },
  {
    title: "Resources",
    links: [
      { label: "Case Studies", href: "/#cases" },
      { label: "FAQ", href: "/#faq" },
      { label: "Book a Meeting", href: BOOK_URL },
      { label: "Support", href: "/contact" },
    ],
  },
];
