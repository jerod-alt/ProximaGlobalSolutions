"use client";

import { motion } from "framer-motion";
import { METRICS } from "@/lib/data";

export default function Metrics() {
  return (
    <section
      style={{
        background: "linear-gradient(180deg,#0A0F1C,#070A14)",
        borderTop: "1px solid rgba(255,255,255,0.05)",
      }}
    >
      <div
        style={{ maxWidth: 1200, margin: "0 auto", padding: "64px 24px" }}
      >
        <div
          className="metrics-grid"
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(4,1fr)",
            gap: 20,
            textAlign: "center",
          }}
        >
          {METRICS.map((m, i) => (
            <motion.div
              key={m.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.1 }}
            >
              <div
                style={{
                  fontSize: "clamp(34px,5vw,52px)",
                  fontWeight: 700,
                  letterSpacing: "-0.03em",
                  background: "linear-gradient(135deg,#fff,#E6C878)",
                  WebkitBackgroundClip: "text",
                  backgroundClip: "text",
                  color: "transparent",
                  fontVariantNumeric: "tabular-nums",
                }}
              >
                {m.value}
              </div>
              <div
                style={{
                  color: "#8A97AC",
                  fontSize: 13.5,
                  marginTop: 8,
                }}
              >
                {m.label}
              </div>
            </motion.div>
          ))}
        </div>
        <p
          style={{
            textAlign: "center",
            margin: "28px 0 0",
            fontFamily: "var(--font-newsreader), Georgia, serif",
            fontStyle: "italic",
            color: "#475569",
            fontSize: 13.5,
          }}
        >
          Markets: US · Canada · UK · Australia. Add your verified figures for
          the remaining metrics.
        </p>
      </div>

      <style>{`
        @media (max-width: 640px) {
          .metrics-grid {
            grid-template-columns: 1fr 1fr !important;
          }
        }
      `}</style>
    </section>
  );
}
