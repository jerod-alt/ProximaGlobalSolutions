"use client";

import { motion } from "framer-motion";
import { BOOK_URL, CONTACT } from "@/lib/data";

export default function CTAContact() {
  return (
    <section
      id="contact"
      style={{
        maxWidth: 1200,
        margin: "0 auto",
        padding: "40px 24px 96px",
        scrollMarginTop: 80,
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        style={{
          position: "relative",
          borderRadius: 28,
          overflow: "hidden",
          border: "1px solid rgba(212,175,90,0.22)",
          background:
            "linear-gradient(135deg,rgba(11,27,58,0.6),rgba(212,175,90,0.07))",
          padding: "clamp(40px,6vw,76px) clamp(28px,5vw,64px)",
          textAlign: "center",
        }}
      >
        {/* Glow */}
        <div
          style={{
            position: "absolute",
            top: -120,
            left: "50%",
            transform: "translateX(-50%)",
            width: 600,
            height: 380,
            background:
              "radial-gradient(ellipse,rgba(212,175,90,0.22),transparent 70%)",
            pointerEvents: "none",
          }}
        />

        <div style={{ position: "relative" }}>
          <h2
            style={{
              margin: 0,
              fontSize: "clamp(32px,5vw,56px)",
              fontWeight: 700,
              letterSpacing: "-0.03em",
              color: "#F5F7FA",
              lineHeight: 1.08,
            }}
          >
            Let&rsquo;s lighten the load.
          </h2>
          <p
            style={{
              margin: "18px auto 0",
              maxWidth: 540,
              color: "#C3CCDA",
              fontSize: 17,
            }}
          >
            Book a 20-minute call and we&rsquo;ll explore how Proxima&rsquo;s
            offshore professionals can support your team — at your pace.
          </p>

          <div
            style={{
              marginTop: 34,
              display: "flex",
              gap: 14,
              justifyContent: "center",
              flexWrap: "wrap",
            }}
          >
            <a
              href={BOOK_URL}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                textDecoration: "none",
                fontWeight: 700,
                color: "#0B1B3A",
                padding: "15px 30px",
                borderRadius: 13,
                background: "linear-gradient(135deg,#E6C878,#D4AF5A)",
                boxShadow: "0 14px 40px rgba(212,175,90,0.4)",
                fontSize: 16,
                transition: "transform 0.2s",
              }}
              onMouseEnter={(e) =>
                ((e.currentTarget as HTMLAnchorElement).style.transform =
                  "translateY(-2px)")
              }
              onMouseLeave={(e) =>
                ((e.currentTarget as HTMLAnchorElement).style.transform =
                  "translateY(0)")
              }
            >
              Book a meeting →
            </a>
            <a
              href={`mailto:${CONTACT.email}`}
              style={{
                textDecoration: "none",
                fontWeight: 600,
                color: "#E2E8F0",
                padding: "15px 30px",
                borderRadius: 13,
                background: "rgba(255,255,255,0.06)",
                border: "1px solid rgba(255,255,255,0.15)",
                fontSize: 16,
                transition: "background 0.2s",
              }}
              onMouseEnter={(e) =>
                ((e.currentTarget as HTMLAnchorElement).style.background =
                  "rgba(255,255,255,0.1)")
              }
              onMouseLeave={(e) =>
                ((e.currentTarget as HTMLAnchorElement).style.background =
                  "rgba(255,255,255,0.06)")
              }
            >
              Email us
            </a>
          </div>

          <div
            style={{
              marginTop: 30,
              display: "flex",
              gap: 28,
              justifyContent: "center",
              flexWrap: "wrap",
              fontSize: 13.5,
              color: "#8A97AC",
            }}
          >
            <span>✉ {CONTACT.email}</span>
            <span>☎ {CONTACT.phone}</span>
            <span
              style={{
                fontFamily: "var(--font-newsreader), Georgia, serif",
                fontStyle: "italic",
                color: "#5A6A8A",
              }}
            >
              office address — add
            </span>
          </div>
        </div>
      </motion.div>
    </section>
  );
}
