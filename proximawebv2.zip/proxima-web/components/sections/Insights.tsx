"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { INSIGHTS } from "@/lib/data";

export default function Insights() {
  return (
    <section
      id="insights"
      style={{
        maxWidth: 1200,
        margin: "0 auto",
        padding: "88px 24px",
        scrollMarginTop: 80,
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        style={{
          display: "flex",
          alignItems: "flex-end",
          justifyContent: "space-between",
          gap: 24,
          flexWrap: "wrap",
          marginBottom: 36,
        }}
      >
        <div>
          <div
            style={{
              fontSize: 13,
              letterSpacing: "0.14em",
              textTransform: "uppercase",
              color: "#D4AF5A",
              marginBottom: 14,
            }}
          >
            Insights
          </div>
          <h2
            style={{
              margin: 0,
              fontSize: "clamp(30px,4vw,46px)",
              fontWeight: 700,
              letterSpacing: "-0.03em",
              color: "#F5F7FA",
            }}
          >
            Thinking &amp; perspectives.
          </h2>
        </div>
        <a
          href="#"
          style={{
            textDecoration: "none",
            color: "#D4AF5A",
            fontWeight: 600,
            fontSize: 14,
            transition: "color 0.15s",
          }}
          onMouseEnter={(e) =>
            ((e.currentTarget as HTMLAnchorElement).style.color = "#E6C878")
          }
          onMouseLeave={(e) =>
            ((e.currentTarget as HTMLAnchorElement).style.color = "#D4AF5A")
          }
        >
          View all →
        </a>
      </motion.div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit,minmax(300px,1fr))",
          gap: 18,
        }}
      >
        {INSIGHTS.map((article, i) => (
          <motion.a
            key={article.title}
            href="#"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: i * 0.1 }}
            whileHover={{ y: -4, transition: { duration: 0.2 } }}
            style={{
              textDecoration: "none",
              borderRadius: 18,
              overflow: "hidden",
              border: "1px solid rgba(255,255,255,0.08)",
              background: "rgba(255,255,255,0.02)",
              display: "flex",
              flexDirection: "column",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLAnchorElement).style.borderColor =
                "rgba(212,175,90,0.3)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLAnchorElement).style.borderColor =
                "rgba(255,255,255,0.08)";
            }}
          >
            <Image
              src={article.img}
              alt={article.title}
              width={600}
              height={338}
              loading="lazy"
              style={{
                display: "block",
                width: "100%",
                height: "auto",
                aspectRatio: "16/9",
                objectFit: "cover",
              }}
            />
            <div style={{ padding: 22 }}>
              <div
                style={{
                  fontSize: 11.5,
                  letterSpacing: "0.06em",
                  textTransform: "uppercase",
                  color: "#5A6A8A",
                }}
              >
                {article.meta}
              </div>
              <div
                style={{
                  color: "#F5F7FA",
                  fontWeight: 600,
                  fontSize: 17,
                  marginTop: 10,
                  lineHeight: 1.35,
                  letterSpacing: "-0.01em",
                }}
              >
                {article.title}
              </div>
              <div
                style={{
                  color: "#D4AF5A",
                  fontSize: 13,
                  fontWeight: 500,
                  marginTop: 14,
                }}
              >
                Read article →
              </div>
            </div>
          </motion.a>
        ))}
      </div>
    </section>
  );
}
