"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { CASE_STUDIES } from "@/lib/data";

export default function CaseStudies() {
  return (
    <section
      id="cases"
      style={{
        maxWidth: 1200,
        margin: "0 auto",
        padding: "88px 24px",
        scrollMarginTop: 80,
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        style={{
          display: "flex",
          alignItems: "flex-end",
          justifyContent: "space-between",
          gap: 24,
          flexWrap: "wrap",
          marginBottom: 36,
        }}
      >
        <div>
          <div
            style={{
              fontSize: 13,
              letterSpacing: "0.14em",
              textTransform: "uppercase",
              color: "#D4AF5A",
              marginBottom: 14,
            }}
          >
            Case studies
          </div>
          <h2
            style={{
              margin: 0,
              fontSize: "clamp(30px,4vw,46px)",
              fontWeight: 700,
              letterSpacing: "-0.03em",
              color: "#F5F7FA",
            }}
          >
            Proof, in practice.
          </h2>
        </div>
        <span
          style={{
            fontFamily: "var(--font-newsreader), Georgia, serif",
            fontStyle: "italic",
            color: "#5A6A8A",
            fontSize: 14,
            maxWidth: 280,
            textAlign: "right",
          }}
        >
          Replace with Proxima&rsquo;s real client outcomes.
        </span>
      </motion.div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit,minmax(300px,1fr))",
          gap: 18,
        }}
      >
        {CASE_STUDIES.map((c, i) => (
          <motion.a
            key={c.title}
            href="#contact"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: i * 0.1 }}
            whileHover={{ y: -4, transition: { duration: 0.2 } }}
            style={{
              textDecoration: "none",
              borderRadius: 18,
              overflow: "hidden",
              border: "1px solid rgba(255,255,255,0.08)",
              background: "rgba(255,255,255,0.02)",
              display: "flex",
              flexDirection: "column",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLAnchorElement).style.borderColor =
                "rgba(212,175,90,0.3)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLAnchorElement).style.borderColor =
                "rgba(255,255,255,0.08)";
            }}
          >
            <Image
              src={c.img}
              alt={c.title}
              width={600}
              height={375}
              loading="lazy"
              style={{
                display: "block",
                width: "100%",
                height: "auto",
                aspectRatio: "16/10",
                objectFit: "cover",
              }}
            />
            <div style={{ padding: 22 }}>
              <div
                style={{
                  fontSize: 11.5,
                  letterSpacing: "0.08em",
                  textTransform: "uppercase",
                  color: "#D4AF5A",
                }}
              >
                {c.tag}
              </div>
              <div
                style={{
                  color: "#F5F7FA",
                  fontWeight: 600,
                  fontSize: 18,
                  marginTop: 10,
                  letterSpacing: "-0.01em",
                }}
              >
                {c.title}
              </div>
              <div
                style={{
                  color: "#8A97AC",
                  fontSize: 13.5,
                  marginTop: 8,
                  lineHeight: 1.55,
                }}
              >
                {c.desc}
              </div>
              <div style={{ marginTop: 16, display: "flex", gap: 18 }}>
                <div>
                  <div
                    style={{
                      color: "#F5F7FA",
                      fontWeight: 700,
                      fontSize: 20,
                    }}
                  >
                    {c.stat}
                  </div>
                  <div style={{ color: "#5A6A8A", fontSize: 11.5 }}>
                    {c.statLabel}
                  </div>
                </div>
              </div>
            </div>
          </motion.a>
        ))}
      </div>
    </section>
  );
}
