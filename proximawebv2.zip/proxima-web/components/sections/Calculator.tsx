"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { BOOK_URL } from "@/lib/data";

function fmt(n: number) {
  return "$" + Math.round(n).toLocaleString("en-US");
}

export default function Calculator() {
  const [count, setCount] = useState(3);
  const [rate, setRate] = useState(1500);
  const [inhouse, setInhouse] = useState(5000);

  const monthly = count * rate;
  const annual = monthly * 12;
  const savings = Math.max(0, count * (inhouse - rate) * 12);
  const hasSavings = savings > 0;

  return (
    <section
      style={{ maxWidth: 1200, margin: "0 auto", padding: "48px 24px" }}
    >
      <div
        className="calc-grid"
        style={{
          display: "grid",
          gridTemplateColumns: "0.95fr 1.05fr",
          gap: 40,
          alignItems: "center",
        }}
      >
        {/* Left: controls */}
        <motion.div
          initial={{ opacity: 0, x: -24 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <div
            style={{
              fontSize: 13,
              letterSpacing: "0.14em",
              textTransform: "uppercase",
              color: "#D4AF5A",
              marginBottom: 14,
            }}
          >
            Savings calculator
          </div>
          <h2
            style={{
              margin: 0,
              fontSize: "clamp(28px,4vw,44px)",
              fontWeight: 700,
              letterSpacing: "-0.03em",
              color: "#F5F7FA",
              lineHeight: 1.1,
            }}
          >
            See what a Proxima team would cost.
          </h2>
          <p style={{ margin: "16px 0 0", color: "#8A97AC", lineHeight: 1.65 }}>
            Roles typically range{" "}
            <strong style={{ color: "#E6C878", fontWeight: 600 }}>
              $1,000–$2,000 / month
            </strong>{" "}
            each. Move the sliders to estimate your monthly investment — and
            your savings versus hiring in-house.
          </p>

          <div
            style={{
              marginTop: 28,
              display: "flex",
              flexDirection: "column",
              gap: 22,
            }}
          >
            <SliderField
              label="Professionals"
              value={count}
              display={String(count)}
              min={1}
              max={20}
              step={1}
              onChange={(v) => setCount(v)}
            />
            <SliderField
              label="Monthly rate per professional"
              value={rate}
              display={fmt(rate)}
              min={1000}
              max={2000}
              step={50}
              onChange={(v) => setRate(v)}
            />

            <div>
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "baseline",
                  marginBottom: 8,
                }}
              >
                <label
                  style={{
                    fontSize: 13.5,
                    color: "#C3CCDA",
                    fontWeight: 500,
                  }}
                >
                  Your in-house cost per role / month
                </label>
                <span style={{ fontSize: 11.5, color: "#5A6A8A" }}>
                  adjust to your market
                </span>
              </div>
              <input
                type="number"
                min={0}
                step={100}
                value={inhouse}
                onChange={(e) =>
                  setInhouse(Math.max(0, Number(e.target.value) || 0))
                }
                aria-label="In-house cost per role per month"
                style={{
                  width: "100%",
                  background: "rgba(7,10,20,0.6)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: 11,
                  padding: "12px 14px",
                  color: "#F5F7FA",
                  font: "inherit",
                  fontSize: 14.5,
                  outline: "none",
                  transition: "border-color 0.2s",
                }}
                onFocus={(e) =>
                  ((e.target as HTMLInputElement).style.borderColor =
                    "rgba(212,175,90,0.5)")
                }
                onBlur={(e) =>
                  ((e.target as HTMLInputElement).style.borderColor =
                    "rgba(255,255,255,0.1)")
                }
              />
            </div>
          </div>
        </motion.div>

        {/* Right: result card */}
        <motion.div
          initial={{ opacity: 0, x: 24 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.1 }}
          style={{
            position: "relative",
            borderRadius: 22,
            overflow: "hidden",
            border: "1px solid rgba(212,175,90,0.22)",
            background:
              "linear-gradient(135deg,rgba(11,27,58,0.6),rgba(212,175,90,0.06))",
            padding: 34,
          }}
        >
          <div
            style={{
              position: "absolute",
              top: -100,
              right: -60,
              width: 320,
              height: 280,
              background:
                "radial-gradient(ellipse,rgba(212,175,90,0.18),transparent 70%)",
              pointerEvents: "none",
            }}
          />
          <div style={{ position: "relative" }}>
            <div
              style={{
                fontSize: 12.5,
                letterSpacing: "0.12em",
                textTransform: "uppercase",
                color: "#8A97AC",
              }}
            >
              Your estimate
            </div>

            <div
              style={{
                marginTop: 18,
                display: "flex",
                flexDirection: "column",
                gap: 16,
              }}
            >
              <ResultRow
                label="Monthly with Proxima"
                value={fmt(monthly)}
                large
                bordered
              />
              <ResultRow
                label="Per year"
                value={fmt(annual)}
                bordered
              />
              {hasSavings && (
                <motion.div
                  key={savings}
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  style={{
                    display: "flex",
                    alignItems: "flex-end",
                    justifyContent: "space-between",
                    gap: 12,
                  }}
                >
                  <span
                    style={{ color: "#C9B583", fontSize: 14.5 }}
                  >
                    Est. yearly savings vs. in-house
                  </span>
                  <span
                    style={{
                      fontSize: "clamp(26px,4vw,34px)",
                      fontWeight: 700,
                      background:
                        "linear-gradient(135deg,#E6C878,#D4AF5A)",
                      WebkitBackgroundClip: "text",
                      backgroundClip: "text",
                      color: "transparent",
                      fontVariantNumeric: "tabular-nums",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {fmt(savings)}
                  </span>
                </motion.div>
              )}
            </div>

            <a
              href={BOOK_URL}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                marginTop: 26,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                textDecoration: "none",
                fontWeight: 700,
                color: "#0B1B3A",
                padding: "14px 24px",
                borderRadius: 13,
                background:
                  "linear-gradient(135deg,#E6C878,#D4AF5A)",
                boxShadow: "0 12px 34px rgba(212,175,90,0.35)",
                fontSize: 15,
                transition: "transform 0.2s",
              }}
              onMouseEnter={(e) =>
                ((e.currentTarget as HTMLAnchorElement).style.transform =
                  "translateY(-2px)")
              }
              onMouseLeave={(e) =>
                ((e.currentTarget as HTMLAnchorElement).style.transform =
                  "translateY(0)")
              }
            >
              Book a free consultation →
            </a>

            <p
              style={{
                margin: "14px 0 0",
                fontSize: 11.5,
                color: "#5A6A8A",
                lineHeight: 1.5,
                textAlign: "center",
              }}
            >
              Estimate only. Final pricing depends on role, scope, and
              seniority — confirmed on your consultation.
            </p>
          </div>
        </motion.div>
      </div>

      <style>{`
        @media (max-width: 768px) {
          .calc-grid {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </section>
  );
}

function SliderField({
  label,
  value,
  display,
  min,
  max,
  step,
  onChange,
}: {
  label: string;
  value: number;
  display: string;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
}) {
  return (
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "baseline",
          marginBottom: 8,
        }}
      >
        <label
          style={{ fontSize: 13.5, color: "#C3CCDA", fontWeight: 500 }}
        >
          {label}
        </label>
        <span
          style={{
            fontFamily: "var(--font-jetbrains), monospace",
            fontSize: 15,
            color: "#E6C878",
          }}
        >
          {display}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        aria-label={label}
      />
    </div>
  );
}

function ResultRow({
  label,
  value,
  large,
  bordered,
}: {
  label: string;
  value: string;
  large?: boolean;
  bordered?: boolean;
}) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "flex-end",
        justifyContent: "space-between",
        gap: 12,
        paddingBottom: bordered ? 16 : 0,
        borderBottom: bordered ? "1px solid rgba(255,255,255,0.08)" : "none",
      }}
    >
      <span style={{ color: "#C3CCDA", fontSize: 14.5 }}>{label}</span>
      <span
        style={{
          fontSize: large ? "clamp(26px,4vw,34px)" : 22,
          fontWeight: large ? 700 : 600,
          color: "#F5F7FA",
          letterSpacing: "-0.02em",
          fontVariantNumeric: "tabular-nums",
          whiteSpace: "nowrap",
        }}
      >
        {value}
      </span>
    </div>
  );
}
