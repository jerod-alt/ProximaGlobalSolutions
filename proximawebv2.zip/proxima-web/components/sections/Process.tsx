"use client";

import { motion } from "framer-motion";
import { STEPS } from "@/lib/data";

export default function Process() {
  return (
    <section
      style={{
        background: "#0A0F1C",
        borderTop: "1px solid rgba(255,255,255,0.05)",
        borderBottom: "1px solid rgba(255,255,255,0.05)",
      }}
    >
      <div
        style={{ maxWidth: 1200, margin: "0 auto", padding: "88px 24px" }}
      >
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          style={{ textAlign: "center", marginBottom: 52 }}
        >
          <div
            style={{
              fontSize: 13,
              letterSpacing: "0.14em",
              textTransform: "uppercase",
              color: "#D4AF5A",
              marginBottom: 14,
            }}
          >
            How we work
          </div>
          <h2
            style={{
              margin: 0,
              fontSize: "clamp(30px,4vw,46px)",
              fontWeight: 700,
              letterSpacing: "-0.03em",
              color: "#F5F7FA",
            }}
          >
            From first call to fully embedded.
          </h2>
        </motion.div>

        <div
          className="process-grid"
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(4,1fr)",
            gap: 16,
          }}
        >
          {STEPS.map((st, i) => (
            <motion.div
              key={st.num}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.1 }}
              style={{
                position: "relative",
                padding: "26px 22px",
                borderRadius: 16,
                background: "rgba(255,255,255,0.02)",
                border: "1px solid rgba(255,255,255,0.07)",
              }}
            >
              <div
                style={{
                  fontFamily: "var(--font-jetbrains), monospace",
                  fontSize: 13,
                  color: "#D4AF5A",
                  letterSpacing: "0.08em",
                }}
              >
                {st.num}
              </div>
              <div
                style={{
                  color: "#F5F7FA",
                  fontWeight: 600,
                  fontSize: 17,
                  marginTop: 16,
                }}
              >
                {st.title}
              </div>
              <div
                style={{
                  color: "#8A97AC",
                  fontSize: 13.5,
                  marginTop: 8,
                  lineHeight: 1.55,
                }}
              >
                {st.desc}
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      <style>{`
        @media (max-width: 768px) {
          .process-grid {
            grid-template-columns: 1fr 1fr !important;
          }
        }
        @media (max-width: 480px) {
          .process-grid {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </section>
  );
}
