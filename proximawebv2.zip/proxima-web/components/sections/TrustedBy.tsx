"use client";

import { motion } from "framer-motion";
import { LOGOS } from "@/lib/data";

export default function TrustedBy() {
  return (
    <section
      style={{
        maxWidth: 1200,
        margin: "0 auto",
        padding: "24px 24px 64px",
      }}
    >
      <p
        style={{
          textAlign: "center",
          fontSize: 12.5,
          letterSpacing: "0.16em",
          textTransform: "uppercase",
          color: "#475569",
          margin: "0 0 26px",
        }}
      >
        Trusted by teams we serve
      </p>
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 0.85 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        style={{
          display: "flex",
          flexWrap: "wrap",
          alignItems: "center",
          justifyContent: "center",
          gap: "18px 48px",
        }}
      >
        {LOGOS.map((logo) => (
          <div
            key={logo}
            style={{
              fontSize: 16,
              fontWeight: 600,
              color: "#8A97AC",
              letterSpacing: "0.01em",
              padding: "8px 18px",
            }}
          >
            {logo}
          </div>
        ))}
      </motion.div>
    </section>
  );
}
