"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { TESTIMONIALS } from "@/lib/data";

export default function Testimonials() {
  return (
    <section
      style={{ maxWidth: 1200, margin: "0 auto", padding: "88px 24px" }}
    >
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        style={{ textAlign: "center", marginBottom: 44 }}
      >
        <div
          style={{
            fontSize: 13,
            letterSpacing: "0.14em",
            textTransform: "uppercase",
            color: "#D4AF5A",
            marginBottom: 14,
          }}
        >
          Testimonials
        </div>
        <h2
          style={{
            margin: 0,
            fontSize: "clamp(30px,4vw,46px)",
            fontWeight: 700,
            letterSpacing: "-0.03em",
            color: "#F5F7FA",
          }}
        >
          In our clients&rsquo; words.
        </h2>
      </motion.div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit,minmax(300px,1fr))",
          gap: 18,
        }}
      >
        {TESTIMONIALS.map((t, i) => (
          <motion.figure
            key={t.name}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: i * 0.1 }}
            style={{
              margin: 0,
              padding: 28,
              borderRadius: 18,
              background: "rgba(255,255,255,0.025)",
              border: "1px solid rgba(255,255,255,0.08)",
              display: "flex",
              flexDirection: "column",
              gap: 18,
            }}
          >
            <div
              style={{
                color: "#D4AF5A",
                fontFamily: "var(--font-newsreader), Georgia, serif",
                fontSize: 34,
                lineHeight: 0,
                height: 18,
              }}
            >
              &ldquo;
            </div>
            <blockquote
              style={{
                margin: 0,
                color: "#E2E8F0",
                fontSize: 15.5,
                lineHeight: 1.6,
                fontFamily: "var(--font-newsreader), Georgia, serif",
                fontStyle: "italic",
              }}
            >
              {t.quote}
            </blockquote>
            <figcaption
              style={{
                display: "flex",
                alignItems: "center",
                gap: 12,
                marginTop: "auto",
              }}
            >
              <Image
                src={t.avatar}
                alt={t.name}
                width={40}
                height={40}
                loading="lazy"
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: "50%",
                  objectFit: "cover",
                  border: "1px solid rgba(255,255,255,0.1)",
                }}
              />
              <span>
                <span
                  style={{
                    display: "block",
                    color: "#F5F7FA",
                    fontWeight: 600,
                    fontSize: 14,
                  }}
                >
                  {t.name}
                </span>
                <span style={{ color: "#5A6A8A", fontSize: 12.5 }}>
                  {t.role}
                </span>
              </span>
            </figcaption>
          </motion.figure>
        ))}
      </div>
    </section>
  );
}
