"use client";

import { motion } from "framer-motion";
import { INDUSTRIES } from "@/lib/data";

export default function Industries() {
  return (
    <section
      id="industries"
      style={{
        background: "#0A0F1C",
        borderTop: "1px solid rgba(255,255,255,0.05)",
        borderBottom: "1px solid rgba(255,255,255,0.05)",
        scrollMarginTop: 80,
      }}
    >
      <div
        style={{ maxWidth: 1200, margin: "0 auto", padding: "88px 24px" }}
      >
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          style={{ textAlign: "center", marginBottom: 44 }}
        >
          <div
            style={{
              fontSize: 13,
              letterSpacing: "0.14em",
              textTransform: "uppercase",
              color: "#D4AF5A",
              marginBottom: 14,
            }}
          >
            Industries
          </div>
          <h2
            style={{
              margin: 0,
              fontSize: "clamp(30px,4vw,46px)",
              fontWeight: 700,
              letterSpacing: "-0.03em",
              color: "#F5F7FA",
            }}
          >
            Experience across your world.
          </h2>
          <p
            style={{
              margin: "14px auto 0",
              color: "#8A97AC",
              maxWidth: 520,
            }}
          >
            We support teams in the sectors we know best.
          </p>
        </motion.div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill,minmax(220px,1fr))",
            gap: 14,
          }}
        >
          {INDUSTRIES.map((ind, i) => (
            <motion.div
              key={ind.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: Math.min(i * 0.05, 0.35) }}
              style={{
                padding: 22,
                borderRadius: 15,
                background: "rgba(255,255,255,0.02)",
                border: "1px solid rgba(255,255,255,0.07)",
                transition: "border-color 0.2s, background 0.2s",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLDivElement).style.borderColor =
                  "rgba(212,175,90,0.3)";
                (e.currentTarget as HTMLDivElement).style.background =
                  "rgba(255,255,255,0.04)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLDivElement).style.borderColor =
                  "rgba(255,255,255,0.07)";
                (e.currentTarget as HTMLDivElement).style.background =
                  "rgba(255,255,255,0.02)";
              }}
            >
              <div
                style={{
                  fontFamily: "var(--font-jetbrains), monospace",
                  fontSize: 12,
                  color: "#D4AF5A",
                  marginBottom: 14,
                }}
              >
                {ind.num}
              </div>
              <div
                style={{ color: "#F5F7FA", fontWeight: 600, fontSize: 16 }}
              >
                {ind.name}
              </div>
              <div
                style={{ color: "#5A6A8A", fontSize: 13, marginTop: 6 }}
              >
                {ind.tag}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
