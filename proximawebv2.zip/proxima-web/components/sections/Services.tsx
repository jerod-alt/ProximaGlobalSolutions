"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { motion } from "framer-motion";
import Fuse from "fuse.js";
import {
  SERVICES,
  SERVICE_CATEGORIES,
  POPULAR_SEARCHES,
  type Service,
} from "@/lib/data";

const fuse = new Fuse(SERVICES, {
  keys: ["title", "desc", "tags", "category"],
  threshold: 0.35,
  includeScore: true,
});

export default function Services() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "/" && document.activeElement !== searchRef.current) {
        e.preventDefault();
        searchRef.current?.focus();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  const setQ = useCallback(
    (q: string) => {
      setQuery(q);
      setCategory("All");
      searchRef.current?.focus();
    },
    []
  );

  const filtered: Service[] = (() => {
    let base = SERVICES;
    if (category !== "All") {
      base = base.filter((s) => s.category === category);
    }
    if (!query.trim()) return base;
    const results = fuse.search(query, { limit: 50 });
    const matchedTitles = new Set(results.map((r) => r.item.title));
    return base.filter((s) => matchedTitles.has(s.title));
  })();

  const hasResults = filtered.length > 0;
  const noResults = !hasResults;

  const chipStyle = (active: boolean) => ({
    font: "inherit",
    fontSize: 13,
    fontWeight: 500,
    padding: "7px 15px",
    borderRadius: 999,
    cursor: "pointer" as const,
    border: active
      ? "1px solid rgba(212,175,90,0.4)"
      : "1px solid rgba(255,255,255,0.1)",
    background: active
      ? "rgba(212,175,90,0.14)"
      : "rgba(255,255,255,0.03)",
    color: active ? "#E6C878" : "#8A97AC",
    transition: "all 0.15s",
    whiteSpace: "nowrap" as const,
  });

  return (
    <section
      id="services"
      style={{
        maxWidth: 1200,
        margin: "0 auto",
        padding: "80px 24px",
        scrollMarginTop: 90,
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        style={{ marginBottom: 32 }}
      >
        <div
          style={{
            fontSize: 13,
            letterSpacing: "0.14em",
            textTransform: "uppercase",
            color: "#D4AF5A",
            marginBottom: 14,
          }}
        >
          What we do
        </div>
        <h2
          style={{
            margin: 0,
            fontSize: "clamp(30px,4vw,46px)",
            fontWeight: 700,
            letterSpacing: "-0.03em",
            color: "#F5F7FA",
            lineHeight: 1.1,
          }}
        >
          Skilled support, fully integrated.
        </h2>
        <p style={{ margin: "14px 0 0", color: "#8A97AC", maxWidth: 560 }}>
          Search our services. Every Proxima professional plugs directly into
          your team, tools, and working hours.
        </p>
      </motion.div>

      {/* Search bar */}
      <div
        style={{
          borderRadius: 18,
          background: "rgba(255,255,255,0.025)",
          border: "1px solid rgba(255,255,255,0.08)",
          padding: 16,
          marginBottom: 28,
          backdropFilter: "blur(12px)",
          WebkitBackdropFilter: "blur(12px)",
        }}
      >
        <div style={{ position: "relative" }}>
          <span
            style={{
              position: "absolute",
              left: 18,
              top: "50%",
              transform: "translateY(-50%)",
              color: "#5A6A8A",
              fontSize: 16,
              pointerEvents: "none",
            }}
          >
            ⌕
          </span>
          <input
            ref={searchRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search services, tasks, support types…  (press /)"
            aria-label="Search services"
            style={{
              width: "100%",
              background: "rgba(7,10,20,0.6)",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: 13,
              padding: "15px 48px 15px 44px",
              color: "#F5F7FA",
              font: "inherit",
              fontSize: 15,
              outline: "none",
              transition: "border-color 0.2s, box-shadow 0.2s",
            }}
            onFocus={(e) => {
              (e.target as HTMLInputElement).style.borderColor =
                "rgba(212,175,90,0.5)";
              (e.target as HTMLInputElement).style.boxShadow =
                "0 0 0 3px rgba(212,175,90,0.12)";
            }}
            onBlur={(e) => {
              (e.target as HTMLInputElement).style.borderColor =
                "rgba(255,255,255,0.1)";
              (e.target as HTMLInputElement).style.boxShadow = "none";
            }}
          />
          {query && (
            <button
              onClick={() => setQuery("")}
              aria-label="Clear search"
              style={{
                position: "absolute",
                right: 12,
                top: "50%",
                transform: "translateY(-50%)",
                background: "rgba(255,255,255,0.06)",
                border: "none",
                color: "#8A97AC",
                width: 26,
                height: 26,
                borderRadius: 7,
                cursor: "pointer",
                fontSize: 14,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                transition: "background 0.15s, color 0.15s",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLButtonElement).style.background =
                  "rgba(255,255,255,0.12)";
                (e.currentTarget as HTMLButtonElement).style.color = "#fff";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLButtonElement).style.background =
                  "rgba(255,255,255,0.06)";
                (e.currentTarget as HTMLButtonElement).style.color = "#8A97AC";
              }}
            >
              ✕
            </button>
          )}
        </div>

        {/* Category chips */}
        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: 8,
            marginTop: 14,
            alignItems: "center",
          }}
        >
          {SERVICE_CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              style={chipStyle(category === cat)}
            >
              {cat}
            </button>
          ))}
          <span
            style={{
              marginLeft: "auto",
              fontSize: 12.5,
              color: "#475569",
              fontFamily: "var(--font-jetbrains), monospace",
              whiteSpace: "nowrap",
            }}
          >
            {filtered.length} result{filtered.length !== 1 ? "s" : ""}
          </span>
        </div>
      </div>

      {/* Results grid */}
      {hasResults && (
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill,minmax(280px,1fr))",
            gap: 16,
          }}
        >
          {filtered.map((svc, i) => (
            <ServiceCard key={svc.num} svc={svc} index={i} />
          ))}
        </div>
      )}

      {/* No results */}
      {noResults && (
        <div
          style={{
            textAlign: "center",
            padding: "56px 24px",
            borderRadius: 16,
            background: "rgba(255,255,255,0.02)",
            border: "1px dashed rgba(255,255,255,0.1)",
          }}
        >
          <div
            style={{ fontSize: 17, color: "#F5F7FA", fontWeight: 600 }}
          >
            No services match &ldquo;{query}&rdquo;.
          </div>
          <div
            style={{ color: "#8A97AC", marginTop: 8, fontSize: 14 }}
          >
            Try a broader term, or browse popular searches:
          </div>
          <div
            style={{
              display: "flex",
              gap: 8,
              justifyContent: "center",
              flexWrap: "wrap",
              marginTop: 18,
            }}
          >
            {POPULAR_SEARCHES.map((p) => (
              <button
                key={p}
                onClick={() => setQ(p)}
                style={{
                  font: "inherit",
                  fontSize: 13,
                  padding: "8px 16px",
                  borderRadius: 999,
                  cursor: "pointer",
                  border: "1px solid rgba(212,175,90,0.25)",
                  background: "rgba(212,175,90,0.08)",
                  color: "#E6C878",
                }}
              >
                {p}
              </button>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}

function ServiceCard({ svc, index }: { svc: Service; index: number }) {
  return (
    <motion.a
      href="#contact"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay: Math.min(index * 0.05, 0.4) }}
      whileHover={{ y: -3, transition: { duration: 0.2 } }}
      style={{
        textDecoration: "none",
        display: "flex",
        flexDirection: "column",
        gap: 12,
        padding: 24,
        borderRadius: 16,
        background: "rgba(255,255,255,0.025)",
        border: "1px solid rgba(255,255,255,0.08)",
        minHeight: 188,
        cursor: "pointer",
      }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLAnchorElement).style.background =
          "rgba(255,255,255,0.05)";
        (e.currentTarget as HTMLAnchorElement).style.borderColor =
          "rgba(212,175,90,0.3)";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLAnchorElement).style.background =
          "rgba(255,255,255,0.025)";
        (e.currentTarget as HTMLAnchorElement).style.borderColor =
          "rgba(255,255,255,0.08)";
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <span
          style={{
            width: 40,
            height: 40,
            borderRadius: 11,
            background:
              "linear-gradient(135deg,rgba(212,175,90,0.25),rgba(212,175,90,0.1))",
            border: "1px solid rgba(212,175,90,0.25)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontFamily: "var(--font-jetbrains), monospace",
            fontSize: 12,
            color: "#E6C878",
          }}
        >
          {svc.num}
        </span>
        <span
          style={{
            fontSize: 11,
            letterSpacing: "0.08em",
            textTransform: "uppercase",
            color: "#5A6A8A",
          }}
        >
          {svc.category}
        </span>
      </div>
      <div
        style={{
          color: "#F5F7FA",
          fontWeight: 600,
          fontSize: 17,
          letterSpacing: "-0.01em",
        }}
      >
        {svc.title}
      </div>
      <div
        style={{
          color: "#8A97AC",
          fontSize: 13.5,
          lineHeight: 1.55,
          flex: 1,
        }}
      >
        {svc.desc}
      </div>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 6,
          color: "#D4AF5A",
          fontSize: 13,
          fontWeight: 500,
        }}
      >
        Learn more →
      </div>
    </motion.a>
  );
}
