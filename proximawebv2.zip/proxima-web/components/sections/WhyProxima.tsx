"use client";

import { motion } from "framer-motion";
import { PILLARS } from "@/lib/data";

export default function WhyProxima() {
  return (
    <section
      style={{ maxWidth: 1200, margin: "0 auto", padding: "88px 24px" }}
    >
      <div
        className="why-grid"
        style={{
          display: "grid",
          gridTemplateColumns: "0.9fr 1.1fr",
          gap: 48,
          alignItems: "center",
        }}
      >
        <motion.div
          initial={{ opacity: 0, x: -24 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <div
            style={{
              fontSize: 13,
              letterSpacing: "0.14em",
              textTransform: "uppercase",
              color: "#D4AF5A",
              marginBottom: 14,
            }}
          >
            Why Proxima
          </div>
          <h2
            style={{
              margin: 0,
              fontSize: "clamp(30px,4vw,46px)",
              fontWeight: 700,
              letterSpacing: "-0.03em",
              color: "#F5F7FA",
              lineHeight: 1.1,
            }}
          >
            Built around your team.
          </h2>
          <p
            style={{
              margin: "18px 0 0",
              color: "#8A97AC",
              lineHeight: 1.65,
            }}
          >
            Our professionals don&rsquo;t work at arm&rsquo;s length — they
            integrate into your tools, processes, and hours as a seamless
            extension of your team. Excellence, partnership, and growth are the
            values we run on.
          </p>
          <a
            href="#contact"
            style={{
              display: "inline-flex",
              marginTop: 26,
              textDecoration: "none",
              color: "#fff",
              fontWeight: 600,
              padding: "13px 24px",
              borderRadius: 12,
              background: "rgba(255,255,255,0.05)",
              border: "1px solid rgba(255,255,255,0.12)",
              fontSize: 14.5,
              transition: "background 0.2s",
            }}
            onMouseEnter={(e) =>
              ((e.currentTarget as HTMLAnchorElement).style.background =
                "rgba(255,255,255,0.09)")
            }
            onMouseLeave={(e) =>
              ((e.currentTarget as HTMLAnchorElement).style.background =
                "rgba(255,255,255,0.05)")
            }
          >
            Talk to our team
          </a>
        </motion.div>

        <div
          style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}
        >
          {PILLARS.map((p, i) => (
            <motion.div
              key={p.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.1 }}
              style={{
                padding: 22,
                borderRadius: 15,
                background: "rgba(255,255,255,0.025)",
                border: "1px solid rgba(255,255,255,0.08)",
              }}
            >
              <div
                style={{
                  width: 42,
                  height: 42,
                  borderRadius: 12,
                  background:
                    "linear-gradient(135deg,rgba(212,175,90,0.25),rgba(212,175,90,0.1))",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  marginBottom: 16,
                  fontSize: 18,
                  color: "#E6C878",
                }}
              >
                {p.icon}
              </div>
              <div
                style={{
                  color: "#F5F7FA",
                  fontWeight: 600,
                  fontSize: 16,
                }}
              >
                {p.title}
              </div>
              <div
                style={{
                  color: "#8A97AC",
                  fontSize: 13.5,
                  marginTop: 7,
                  lineHeight: 1.55,
                }}
              >
                {p.desc}
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      <style>{`
        @media (max-width: 768px) {
          .why-grid {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </section>
  );
}
