"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { BOOK_URL } from "@/lib/data";

export default function Hero() {
  return (
    <section
      style={{
        maxWidth: 1200,
        margin: "0 auto",
        padding: "96px 24px 80px",
        textAlign: "center",
        position: "relative",
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        style={{
          display: "inline-flex",
          alignItems: "center",
          gap: 9,
          padding: "7px 15px",
          borderRadius: 999,
          background: "rgba(255,255,255,0.04)",
          border: "1px solid rgba(212,175,90,0.2)",
          fontSize: 13,
          color: "#C9B583",
        }}
      >
        <span
          style={{
            width: 6,
            height: 6,
            borderRadius: "50%",
            background: "#D4AF5A",
            boxShadow: "0 0 8px #D4AF5A",
            flexShrink: 0,
          }}
        />
        Outsourcing · Virtual Staffing · AI Automation
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.55, delay: 0.1 }}
        style={{
          margin: "26px auto 0",
          maxWidth: 960,
          fontSize: "clamp(38px,6vw,72px)",
          lineHeight: 1.06,
          fontWeight: 700,
          letterSpacing: "-0.035em",
          color: "#F5F7FA",
        }}
      >
        Scale your business with elite global talent and{" "}
        <span
          style={{
            fontFamily: "var(--font-newsreader), Georgia, serif",
            fontWeight: 500,
            fontStyle: "italic",
            background: "linear-gradient(120deg,#E6C878,#D4AF5A)",
            WebkitBackgroundClip: "text",
            backgroundClip: "text",
            color: "transparent",
          }}
        >
          AI-powered operations
        </span>
        .
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        style={{
          margin: "26px auto 0",
          maxWidth: 640,
          fontSize: "clamp(16px,2vw,19px)",
          color: "#8A97AC",
          lineHeight: 1.65,
        }}
      >
        Proxima Global Solutions helps businesses across the US, Canada, UK, and
        Australia streamline operations, reduce costs, and accelerate growth —
        through outsourcing, virtual staffing, and intelligent automation.
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
        style={{
          marginTop: 38,
          display: "flex",
          gap: 14,
          justifyContent: "center",
          flexWrap: "wrap",
        }}
      >
        <a
          href={BOOK_URL}
          target="_blank"
          rel="noopener noreferrer"
          style={{
            textDecoration: "none",
            fontWeight: 700,
            color: "#0B1B3A",
            padding: "14px 26px",
            borderRadius: 13,
            background: "linear-gradient(135deg,#E6C878,#D4AF5A)",
            boxShadow: "0 12px 34px rgba(212,175,90,0.35)",
            fontSize: 15.5,
            transition: "transform 0.2s, box-shadow 0.2s",
          }}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLAnchorElement).style.transform =
              "translateY(-2px)";
            (e.currentTarget as HTMLAnchorElement).style.boxShadow =
              "0 16px 44px rgba(212,175,90,0.5)";
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLAnchorElement).style.transform =
              "translateY(0)";
            (e.currentTarget as HTMLAnchorElement).style.boxShadow =
              "0 12px 34px rgba(212,175,90,0.35)";
          }}
        >
          Book free consultation →
        </a>
        <a
          href="#services"
          style={{
            textDecoration: "none",
            fontWeight: 600,
            color: "#E2E8F0",
            padding: "14px 26px",
            borderRadius: 13,
            background: "rgba(255,255,255,0.04)",
            border: "1px solid rgba(255,255,255,0.12)",
            fontSize: 15.5,
            transition: "background 0.2s, border-color 0.2s",
          }}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLAnchorElement).style.background =
              "rgba(255,255,255,0.08)";
            (e.currentTarget as HTMLAnchorElement).style.borderColor =
              "rgba(255,255,255,0.2)";
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLAnchorElement).style.background =
              "rgba(255,255,255,0.04)";
            (e.currentTarget as HTMLAnchorElement).style.borderColor =
              "rgba(255,255,255,0.12)";
          }}
        >
          Explore services
        </a>
      </motion.div>

      {/* Hero image */}
      <motion.div
        initial={{ opacity: 0, y: 32 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.4 }}
        style={{
          margin: "64px auto 0",
          maxWidth: 980,
          position: "relative",
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: -1,
            borderRadius: 22,
            background:
              "linear-gradient(135deg,rgba(212,175,90,0.4),rgba(168,196,232,0.2),transparent 60%)",
            filter: "blur(2px)",
            opacity: 0.5,
          }}
        />
        <div
          style={{
            position: "relative",
            borderRadius: 20,
            overflow: "hidden",
            border: "1px solid rgba(255,255,255,0.1)",
            background: "rgba(10,15,28,0.8)",
            boxShadow: "0 40px 100px rgba(0,0,0,0.6)",
          }}
        >
          <div
            style={{
              height: 42,
              display: "flex",
              alignItems: "center",
              gap: 7,
              padding: "0 16px",
              borderBottom: "1px solid rgba(255,255,255,0.06)",
              background: "rgba(255,255,255,0.02)",
            }}
          >
            {["#3a455c", "#3a455c", "#3a455c"].map((color, i) => (
              <span
                key={i}
                style={{
                  width: 11,
                  height: 11,
                  borderRadius: "50%",
                  background: color,
                }}
              />
            ))}
          </div>
          <Image
            src="/hero.png"
            alt="Proxima Global Solutions team collaborating in a modern office"
            width={980}
            height={520}
            priority
            style={{ display: "block", width: "100%", height: "auto", objectFit: "cover" }}
          />
        </div>
      </motion.div>
    </section>
  );
}
