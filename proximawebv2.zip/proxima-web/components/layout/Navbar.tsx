"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { BOOK_URL } from "@/lib/data";

const NAV_LINKS = [
  { label: "About", href: "/about" },
  { label: "Industries", href: "/#industries" },
  { label: "Insights", href: "/#insights" },
  { label: "Contact", href: "/contact" },
];

const MEGA_ITEMS = [
  {
    title: "Administrative & Operations",
    sub: "Assistants, ops & data entry",
  },
  { title: "Accounting & Finance", sub: "Bookkeeping, AR, AP & payroll" },
  { title: "Sales & Customer", sub: "Lead gen, support & success" },
  { title: "AI & Automation", sub: "Workflows, chatbots & BI" },
  { title: "HVAC & Solar", sub: "Dispatch, coordination & permits" },
  { title: "Business Intelligence", sub: "Dashboards, KPIs & reporting" },
];

export default function Navbar({
  showAnnouncement = true,
}: {
  showAnnouncement?: boolean;
}) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [megaOpen, setMegaOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      {showAnnouncement && (
        <div
          style={{
            background: "rgba(212,175,90,0.07)",
            borderBottom: "1px solid rgba(212,175,90,0.14)",
            position: "relative",
            zIndex: 5,
          }}
        >
          <a
            href={BOOK_URL}
            target="_blank"
            rel="noopener noreferrer"
            style={{
              textDecoration: "none",
              display: "flex",
              maxWidth: 1200,
              margin: "0 auto",
              padding: "9px 24px",
              alignItems: "center",
              justifyContent: "center",
              gap: 10,
              fontSize: 12.5,
              color: "#C9B583",
              letterSpacing: "0.01em",
              textAlign: "center",
            }}
          >
            <span
              style={{
                width: 6,
                height: 6,
                borderRadius: "50%",
                background: "#D4AF5A",
                boxShadow: "0 0 10px #D4AF5A",
                flexShrink: 0,
              }}
            />
            <span>
              Serving teams across the US, Canada, UK &amp; Australia —{" "}
              <span style={{ color: "#E6C878", fontWeight: 600 }}>
                book a free consultation →
              </span>
            </span>
          </a>
        </div>
      )}

      <header
        style={{
          position: "sticky",
          top: 0,
          zIndex: 50,
          backdropFilter: "blur(18px)",
          WebkitBackdropFilter: "blur(18px)",
          background: scrolled
            ? "rgba(7,10,20,0.9)"
            : "rgba(7,10,20,0.74)",
          borderBottom: "1px solid rgba(255,255,255,0.06)",
          transition: "background 0.2s",
        }}
      >
        <nav
          style={{
            maxWidth: 1200,
            margin: "0 auto",
            padding: "0 24px",
            height: 70,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 24,
          }}
        >
          {/* Logo */}
          <Link
            href="/"
            style={{
              display: "flex",
              alignItems: "center",
              gap: 11,
              textDecoration: "none",
              flexShrink: 0,
            }}
          >
            <span
              style={{
                width: 34,
                height: 34,
                borderRadius: 9,
                background: "linear-gradient(140deg,#0B1B3A,#13284f)",
                border: "1px solid rgba(212,175,90,0.4)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                boxShadow: "0 6px 20px rgba(11,27,58,0.6)",
              }}
            >
              <span
                style={{
                  width: 12,
                  height: 12,
                  borderRadius: "50%",
                  border: "2.5px solid #D4AF5A",
                  display: "block",
                }}
              />
            </span>
            <span
              style={{
                display: "flex",
                flexDirection: "column",
                lineHeight: 1,
              }}
            >
              <span
                style={{
                  color: "#F5F7FA",
                  fontWeight: 700,
                  fontSize: 15.5,
                  letterSpacing: "0.02em",
                }}
              >
                Proxima{" "}
                <span style={{ color: "#D4AF5A" }}>Global</span>
              </span>
              <span
                style={{
                  color: "#5A6A8A",
                  fontSize: 8.5,
                  letterSpacing: "0.22em",
                  textTransform: "uppercase",
                  marginTop: 3,
                }}
              >
                Excellence · Partnership · Growth
              </span>
            </span>
          </Link>

          {/* Desktop nav links */}
          <div
            className="hidden md:flex"
            style={{ alignItems: "center", gap: 4 }}
          >
            {/* Services mega menu trigger */}
            <div
              style={{ position: "relative" }}
              onMouseEnter={() => setMegaOpen(true)}
              onMouseLeave={() => setMegaOpen(false)}
            >
              <button
                style={{
                  background: "none",
                  border: "none",
                  color: "#C3CCDA",
                  font: "inherit",
                  fontSize: 14.5,
                  padding: "10px 14px",
                  borderRadius: 9,
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: 6,
                  transition: "background 0.15s, color 0.15s",
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLButtonElement).style.background =
                    "rgba(255,255,255,0.05)";
                  (e.currentTarget as HTMLButtonElement).style.color = "#fff";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLButtonElement).style.background =
                    "none";
                  (e.currentTarget as HTMLButtonElement).style.color =
                    "#C3CCDA";
                }}
              >
                Services
                <span
                  style={{
                    width: 5,
                    height: 5,
                    borderRight: "1.5px solid currentColor",
                    borderBottom: "1.5px solid currentColor",
                    transform: megaOpen
                      ? "rotate(-135deg) translateY(2px)"
                      : "rotate(45deg) translateY(-1px)",
                    display: "inline-block",
                    opacity: 0.6,
                    transition: "transform 0.2s",
                  }}
                />
              </button>

              {megaOpen && (
                <div
                  style={{
                    position: "absolute",
                    top: "calc(100% + 8px)",
                    left: "50%",
                    transform: "translateX(-50%)",
                    width: 560,
                    padding: 18,
                    borderRadius: 18,
                    background: "rgba(10,15,28,0.97)",
                    backdropFilter: "blur(24px)",
                    WebkitBackdropFilter: "blur(24px)",
                    border: "1px solid rgba(255,255,255,0.08)",
                    boxShadow: "0 30px 80px rgba(0,0,0,0.6)",
                    display: "grid",
                    gridTemplateColumns: "1fr 1fr",
                    gap: 6,
                  }}
                >
                  {MEGA_ITEMS.map((item) => (
                    <MegaMenuItem key={item.title} {...item} />
                  ))}
                  <a
                    href="/services"
                    onClick={() => setMegaOpen(false)}
                    style={{
                      gridColumn: "1 / -1",
                      textDecoration: "none",
                      marginTop: 4,
                      padding: "13px 14px",
                      borderRadius: 12,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      background:
                        "linear-gradient(135deg,rgba(212,175,90,0.16),rgba(212,175,90,0.06))",
                      border: "1px solid rgba(212,175,90,0.22)",
                    }}
                  >
                    <span
                      style={{
                        color: "#E6C878",
                        fontWeight: 600,
                        fontSize: 13.5,
                      }}
                    >
                      Browse all services
                    </span>
                    <span style={{ color: "#D4AF5A" }}>→</span>
                  </a>
                </div>
              )}
            </div>

            {NAV_LINKS.map((link) => (
              <NavLink key={link.href} href={link.href} label={link.label} />
            ))}
          </div>

          {/* CTA + burger */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 10,
              flexShrink: 0,
            }}
          >
            <a
              href={BOOK_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:block"
              style={{
                textDecoration: "none",
                fontSize: 14,
                fontWeight: 700,
                color: "#0B1B3A",
                padding: "10px 18px",
                borderRadius: 11,
                background: "linear-gradient(135deg,#E6C878,#D4AF5A)",
                boxShadow: "0 8px 24px rgba(212,175,90,0.35)",
                transition: "box-shadow 0.2s, transform 0.2s",
                whiteSpace: "nowrap",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLAnchorElement).style.boxShadow =
                  "0 10px 30px rgba(212,175,90,0.5)";
                (e.currentTarget as HTMLAnchorElement).style.transform =
                  "translateY(-1px)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLAnchorElement).style.boxShadow =
                  "0 8px 24px rgba(212,175,90,0.35)";
                (e.currentTarget as HTMLAnchorElement).style.transform =
                  "translateY(0)";
              }}
            >
              Book a meeting
            </a>

            {/* Burger */}
            <button
              className="flex md:hidden"
              onClick={() => setMobileOpen((v) => !v)}
              aria-label={mobileOpen ? "Close menu" : "Open menu"}
              style={{
                background: "rgba(255,255,255,0.05)",
                border: "1px solid rgba(255,255,255,0.1)",
                borderRadius: 10,
                width: 40,
                height: 40,
                cursor: "pointer",
                color: "#fff",
                alignItems: "center",
                justifyContent: "center",
                flexDirection: "column",
                gap: 4,
              }}
            >
              <span
                style={{
                  width: 16,
                  height: 1.5,
                  background: "#fff",
                  display: "block",
                  transition: "transform 0.2s",
                  transform: mobileOpen
                    ? "rotate(45deg) translate(4px,4px)"
                    : "none",
                }}
              />
              <span
                style={{
                  width: 16,
                  height: 1.5,
                  background: "#fff",
                  display: "block",
                  transition: "transform 0.2s, opacity 0.2s",
                  opacity: mobileOpen ? 0 : 1,
                }}
              />
              <span
                style={{
                  width: 16,
                  height: 1.5,
                  background: "#fff",
                  display: "block",
                  transition: "transform 0.2s",
                  transform: mobileOpen
                    ? "rotate(-45deg) translate(4px,-4px)"
                    : "none",
                }}
              />
            </button>
          </div>
        </nav>

        {/* Mobile menu */}
        {mobileOpen && (
          <div
            style={{
              borderTop: "1px solid rgba(255,255,255,0.06)",
              background: "rgba(7,10,20,0.97)",
              padding: "14px 24px 22px",
              display: "flex",
              flexDirection: "column",
              gap: 4,
            }}
          >
            {[
              { href: "/services", label: "Services" },
              ...NAV_LINKS,
            ].map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                style={{
                  textDecoration: "none",
                  color: "#C3CCDA",
                  padding: "12px 6px",
                  borderBottom: "1px solid rgba(255,255,255,0.05)",
                  fontSize: 15,
                }}
              >
                {link.label}
              </a>
            ))}
            <a
              href={BOOK_URL}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setMobileOpen(false)}
              style={{
                marginTop: 12,
                textDecoration: "none",
                fontWeight: 700,
                color: "#0B1B3A",
                padding: "13px 20px",
                borderRadius: 11,
                background: "linear-gradient(135deg,#E6C878,#D4AF5A)",
                textAlign: "center",
                fontSize: 15,
              }}
            >
              Book a meeting
            </a>
          </div>
        )}
      </header>
    </>
  );
}

function NavLink({ href, label }: { href: string; label: string }) {
  return (
    <a
      href={href}
      style={{
        textDecoration: "none",
        color: "#C3CCDA",
        fontSize: 14.5,
        padding: "10px 14px",
        borderRadius: 9,
        transition: "background 0.15s, color 0.15s",
        whiteSpace: "nowrap",
      }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLAnchorElement).style.background =
          "rgba(255,255,255,0.05)";
        (e.currentTarget as HTMLAnchorElement).style.color = "#fff";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLAnchorElement).style.background = "none";
        (e.currentTarget as HTMLAnchorElement).style.color = "#C3CCDA";
      }}
    >
      {label}
    </a>
  );
}

function MegaMenuItem({ title, sub }: { title: string; sub: string }) {
  return (
    <a
      href="/services"
      style={{
        textDecoration: "none",
        padding: "13px 14px",
        borderRadius: 12,
        display: "block",
        transition: "background 0.15s",
      }}
      onMouseEnter={(e) =>
        ((e.currentTarget as HTMLAnchorElement).style.background =
          "rgba(255,255,255,0.05)")
      }
      onMouseLeave={(e) =>
        ((e.currentTarget as HTMLAnchorElement).style.background = "none")
      }
    >
      <div style={{ color: "#F5F7FA", fontWeight: 600, fontSize: 14 }}>
        {title}
      </div>
      <div style={{ color: "#5A6A8A", fontSize: 12.5, marginTop: 2 }}>
        {sub}
      </div>
    </a>
  );
}
