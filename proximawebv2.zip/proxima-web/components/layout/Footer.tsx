"use client";

import { useState } from "react";
import { BOOK_URL, CONTACT, FOOTER_COLS } from "@/lib/data";

const SOCIALS = [
  { name: "Li", url: CONTACT.linkedin, label: "LinkedIn" },
  { name: "X", url: "#", label: "X / Twitter" },
  { name: "IG", url: "#", label: "Instagram" },
  { name: "FB", url: "#", label: "Facebook" },
];

export default function Footer() {
  const [subscribed, setSubscribed] = useState(false);
  const year = new Date().getFullYear();

  return (
    <footer
      style={{
        position: "relative",
        zIndex: 1,
        borderTop: "1px solid rgba(255,255,255,0.06)",
        background: "#070A14",
      }}
    >
      <div
        style={{
          maxWidth: 1200,
          margin: "0 auto",
          padding: "64px 24px 36px",
        }}
      >
        <div
          className="footer-grid"
          style={{
            display: "grid",
            gridTemplateColumns: "1.5fr 1fr 1fr 1fr 1.6fr",
            gap: 40,
          }}
        >
          {/* Brand col */}
          <div>
            <a
              href="#top"
              style={{
                display: "flex",
                alignItems: "center",
                gap: 11,
                textDecoration: "none",
              }}
            >
              <span
                style={{
                  width: 34,
                  height: 34,
                  borderRadius: 9,
                  background: "linear-gradient(140deg,#0B1B3A,#13284f)",
                  border: "1px solid rgba(212,175,90,0.4)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <span
                  style={{
                    width: 12,
                    height: 12,
                    borderRadius: "50%",
                    border: "2.5px solid #D4AF5A",
                    display: "block",
                  }}
                />
              </span>
              <span
                style={{ color: "#F5F7FA", fontWeight: 700, fontSize: 16 }}
              >
                Proxima <span style={{ color: "#D4AF5A" }}>Global</span>
              </span>
            </a>
            <p
              style={{
                color: "#5A6A8A",
                fontSize: 13.5,
                margin: "18px 0 0",
                maxWidth: 270,
                lineHeight: 1.6,
              }}
            >
              Empowering businesses with world-class talent, smart automation,
              and scalable business solutions.
            </p>
            <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
              {SOCIALS.map((s) => (
                <a
                  key={s.name}
                  href={s.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={s.label}
                  style={{
                    width: 36,
                    height: 36,
                    borderRadius: 10,
                    background: "rgba(255,255,255,0.04)",
                    border: "1px solid rgba(255,255,255,0.08)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "#8A97AC",
                    textDecoration: "none",
                    fontSize: 11,
                    fontFamily: "var(--font-jetbrains), monospace",
                    fontWeight: 500,
                    transition: "background 0.15s, color 0.15s",
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLAnchorElement).style.background =
                      "rgba(212,175,90,0.12)";
                    (e.currentTarget as HTMLAnchorElement).style.color =
                      "#E6C878";
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLAnchorElement).style.background =
                      "rgba(255,255,255,0.04)";
                    (e.currentTarget as HTMLAnchorElement).style.color =
                      "#8A97AC";
                  }}
                >
                  {s.name}
                </a>
              ))}
            </div>
          </div>

          {/* Link cols */}
          {FOOTER_COLS.map((col) => (
            <div key={col.title}>
              <div
                style={{
                  color: "#F5F7FA",
                  fontWeight: 600,
                  fontSize: 13,
                  letterSpacing: "0.04em",
                  textTransform: "uppercase",
                  marginBottom: 16,
                }}
              >
                {col.title}
              </div>
              <div
                style={{ display: "flex", flexDirection: "column", gap: 11 }}
              >
                {col.links.map((lnk) => (
                  <a
                    key={lnk.label}
                    href={lnk.href}
                    target={lnk.href.startsWith("http") ? "_blank" : undefined}
                    rel={lnk.href.startsWith("http") ? "noopener noreferrer" : undefined}
                    style={{
                      textDecoration: "none",
                      color: "#8A97AC",
                      fontSize: 13.5,
                      transition: "color 0.15s",
                    }}
                    onMouseEnter={(e) =>
                      ((e.currentTarget as HTMLAnchorElement).style.color =
                        "#fff")
                    }
                    onMouseLeave={(e) =>
                      ((e.currentTarget as HTMLAnchorElement).style.color =
                        "#8A97AC")
                    }
                  >
                    {lnk.label}
                  </a>
                ))}
              </div>
            </div>
          ))}

          {/* Newsletter */}
          <div>
            <div
              style={{
                color: "#F5F7FA",
                fontWeight: 600,
                fontSize: 13,
                letterSpacing: "0.04em",
                textTransform: "uppercase",
                marginBottom: 16,
              }}
            >
              Newsletter
            </div>
            <p
              style={{
                color: "#8A97AC",
                fontSize: 13.5,
                margin: "0 0 14px",
                lineHeight: 1.55,
              }}
            >
              Insights to your inbox. No noise.
            </p>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setSubscribed(true);
              }}
              style={{ display: "flex", gap: 8, flexWrap: "wrap" }}
            >
              <input
                type="email"
                required
                placeholder="you@company.com"
                aria-label="Email address"
                style={{
                  flex: 1,
                  minWidth: 140,
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: 11,
                  padding: "11px 14px",
                  color: "#F5F7FA",
                  font: "inherit",
                  fontSize: 13.5,
                  outline: "none",
                  transition: "border-color 0.2s",
                }}
                onFocus={(e) =>
                  ((e.target as HTMLInputElement).style.borderColor =
                    "rgba(212,175,90,0.5)")
                }
                onBlur={(e) =>
                  ((e.target as HTMLInputElement).style.borderColor =
                    "rgba(255,255,255,0.1)")
                }
              />
              <button
                type="submit"
                style={{
                  background: "linear-gradient(135deg,#E6C878,#D4AF5A)",
                  border: "none",
                  color: "#0B1B3A",
                  font: "inherit",
                  fontWeight: 700,
                  fontSize: 13.5,
                  padding: "11px 18px",
                  borderRadius: 11,
                  cursor: "pointer",
                }}
              >
                Subscribe
              </button>
            </form>
            {subscribed && (
              <div
                style={{ marginTop: 10, fontSize: 13, color: "#79C998" }}
              >
                ✓ Subscribed — confirmation on the way.
              </div>
            )}
          </div>
        </div>

        {/* Bottom bar */}
        <div
          style={{
            marginTop: 48,
            paddingTop: 24,
            borderTop: "1px solid rgba(255,255,255,0.06)",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 16,
            flexWrap: "wrap",
          }}
        >
          <span style={{ color: "#475569", fontSize: 12.5 }}>
            © {year} Proxima Global Solutions. All rights reserved.
          </span>
          <div style={{ display: "flex", gap: 22 }}>
            {["Privacy Policy", "Terms", "Cookies"].map((item) => (
              <a
                key={item}
                href="#"
                style={{
                  textDecoration: "none",
                  color: "#5A6A8A",
                  fontSize: 12.5,
                  transition: "color 0.15s",
                }}
                onMouseEnter={(e) =>
                  ((e.currentTarget as HTMLAnchorElement).style.color = "#fff")
                }
                onMouseLeave={(e) =>
                  ((e.currentTarget as HTMLAnchorElement).style.color =
                    "#5A6A8A")
                }
              >
                {item}
              </a>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @media (max-width: 900px) {
          .footer-grid {
            grid-template-columns: 1fr 1fr !important;
          }
        }
        @media (max-width: 560px) {
          .footer-grid {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </footer>
  );
}
