import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { ReactNode } from "react";

export default function PageShell({ children }: { children: ReactNode }) {
  return (
    <div
      style={{
        background: "#070A14",
        color: "#C3CCDA",
        fontFamily: "var(--font-inter), system-ui, sans-serif",
        overflowX: "hidden",
        position: "relative",
        minHeight: "100vh",
      }}
    >
      <div
        aria-hidden="true"
        style={{
          position: "fixed",
          top: 0,
          left: "50%",
          transform: "translateX(-50%)",
          width: 1100,
          height: 600,
          background:
            "radial-gradient(ellipse at center, rgba(212,175,90,0.10), rgba(168,196,232,0.04) 45%, transparent 70%)",
          pointerEvents: "none",
          filter: "blur(8px)",
          zIndex: 0,
        }}
      />
      <Navbar />
      <main style={{ position: "relative", zIndex: 1, minHeight: "80vh" }}>
        {children}
      </main>
      <Footer />
    </div>
  );
}
