import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import Hero from "@/components/sections/Hero";
import TrustedBy from "@/components/sections/TrustedBy";
import Services from "@/components/sections/Services";
import Industries from "@/components/sections/Industries";
import WhyProxima from "@/components/sections/WhyProxima";
import Process from "@/components/sections/Process";
import CaseStudies from "@/components/sections/CaseStudies";
import Metrics from "@/components/sections/Metrics";
import Testimonials from "@/components/sections/Testimonials";
import FAQ from "@/components/sections/FAQ";
import Insights from "@/components/sections/Insights";
import Calculator from "@/components/sections/Calculator";
import CTAContact from "@/components/sections/CTAContact";

export default function Home() {
  return (
    <div
      style={{
        background: "#070A14",
        color: "#C3CCDA",
        fontFamily: "var(--font-inter), system-ui, sans-serif",
        overflowX: "hidden",
        position: "relative",
      }}
    >
      {/* Background glow */}
      <div
        aria-hidden="true"
        style={{
          position: "absolute",
          top: -260,
          left: "50%",
          transform: "translateX(-50%)",
          width: 1100,
          height: 760,
          background:
            "radial-gradient(ellipse at center, rgba(212,175,90,0.16), rgba(168,196,232,0.05) 45%, transparent 70%)",
          pointerEvents: "none",
          filter: "blur(8px)",
          zIndex: 0,
        }}
      />

      <Navbar showAnnouncement />

      <main id="top" style={{ position: "relative", zIndex: 1 }}>
        <Hero />
        <TrustedBy />
        <Services />
        <Industries />
        <WhyProxima />
        <Process />
        <CaseStudies />
        <Metrics />
        <Testimonials />
        <FAQ />
        <Insights />
        <Calculator />
        <CTAContact />
      </main>

      <Footer />
    </div>
  );
}
