"use client";

import { motion } from "framer-motion";
import PageShell from "@/components/layout/PageShell";
import Services from "@/components/sections/Services";
import { BOOK_URL } from "@/lib/data";

export default function ServicesPage() {
  return (
    <PageShell>
      {/* Page header */}
      <section
        style={{
          maxWidth: 1200,
          margin: "0 auto",
          padding: "90px 24px 0",
          textAlign: "center",
        }}
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div
            style={{
              fontSize: 12,
              letterSpacing: "0.18em",
              textTransform: "uppercase",
              color: "#D4AF5A",
              marginBottom: 18,
            }}
          >
            43 services across 9 categories
          </div>
          <h1
            style={{
              margin: 0,
              fontSize: "clamp(38px,6vw,68px)",
              fontWeight: 700,
              letterSpacing: "-0.03em",
              color: "#F5F7FA",
              lineHeight: 1.06,
              fontFamily: "var(--font-newsreader), Georgia, serif",
            }}
          >
            Every role your business needs.
          </h1>
          <p
            style={{
              margin: "20px auto 0",
              maxWidth: 520,
              color: "#8A97AC",
              fontSize: 17,
              lineHeight: 1.65,
            }}
          >
            Search or browse our full service directory. Each role is staffed
            with vetted offshore professionals at{" "}
            <strong style={{ color: "#E6C878", fontWeight: 600 }}>
              $1,000–$2,000 / month.
            </strong>
          </p>

          <div
            style={{
              marginTop: 28,
              display: "flex",
              gap: 12,
              justifyContent: "center",
              flexWrap: "wrap",
            }}
          >
            <a
              href={BOOK_URL}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                textDecoration: "none",
                fontWeight: 700,
                color: "#0B1B3A",
                padding: "13px 26px",
                borderRadius: 12,
                background: "linear-gradient(135deg,#E6C878,#D4AF5A)",
                boxShadow: "0 10px 30px rgba(212,175,90,0.35)",
                fontSize: 15,
              }}
            >
              Book a consultation →
            </a>
            <a
              href="/contact"
              style={{
                textDecoration: "none",
                fontWeight: 600,
                color: "#E2E8F0",
                padding: "13px 26px",
                borderRadius: 12,
                background: "rgba(255,255,255,0.05)",
                border: "1px solid rgba(255,255,255,0.12)",
                fontSize: 15,
              }}
            >
              Talk to us
            </a>
          </div>
        </motion.div>
      </section>

      {/* Full services directory */}
      <Services />
    </PageShell>
  );
}
