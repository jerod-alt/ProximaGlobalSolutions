"use client";

import { motion } from "framer-motion";
import PageShell from "@/components/layout/PageShell";
import { BOOK_URL, PILLARS, METRICS, CONTACT } from "@/lib/data";

const fade = (delay = 0) => ({
  initial: { opacity: 0, y: 22 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.5, delay },
});

export default function AboutPage() {
  return (
    <PageShell>
      {/* Hero */}
      <section
        style={{
          maxWidth: 1200,
          margin: "0 auto",
          padding: "100px 24px 80px",
          textAlign: "center",
        }}
      >
        <motion.div {...fade()}>
          <div
            style={{
              fontSize: 12,
              letterSpacing: "0.18em",
              textTransform: "uppercase",
              color: "#D4AF5A",
              marginBottom: 20,
            }}
          >
            About Proxima
          </div>
          <h1
            style={{
              margin: 0,
              fontSize: "clamp(42px,7vw,76px)",
              fontWeight: 700,
              letterSpacing: "-0.03em",
              color: "#F5F7FA",
              lineHeight: 1.05,
              fontFamily: "var(--font-newsreader), Georgia, serif",
            }}
          >
            Built to help great teams
            <br />
            do more.
          </h1>
          <p
            style={{
              margin: "24px auto 0",
              maxWidth: 560,
              color: "#8A97AC",
              fontSize: 18,
              lineHeight: 1.65,
            }}
          >
            Proxima connects ambitious businesses with exceptional offshore
            talent — so your best people can focus on what only they can do.
          </p>
        </motion.div>
      </section>

      {/* Story */}
      <section
        style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px 96px" }}
      >
        <div className="about-story-grid">
          <motion.div {...fade()}>
            <div
              style={{
                fontSize: 12,
                letterSpacing: "0.14em",
                textTransform: "uppercase",
                color: "#D4AF5A",
                marginBottom: 16,
              }}
            >
              Our story
            </div>
            <h2
              style={{
                margin: "0 0 24px",
                fontSize: "clamp(26px,3.5vw,40px)",
                fontWeight: 700,
                letterSpacing: "-0.03em",
                color: "#F5F7FA",
                lineHeight: 1.1,
              }}
            >
              A problem we saw firsthand.
            </h2>
            <p
              style={{
                color: "#8A97AC",
                lineHeight: 1.75,
                margin: "0 0 18px",
                fontSize: 16,
              }}
            >
              Jerod Gonzales founded Proxima after watching growing businesses
              stall — not from lack of ambition, but from the weight of admin,
              back-office work, and operational overhead that pulled senior
              people away from high-leverage decisions.
            </p>
            <p
              style={{
                color: "#8A97AC",
                lineHeight: 1.75,
                margin: 0,
                fontSize: 16,
              }}
            >
              The solution was clear: an enormous pool of experienced,
              professional talent ready to embed directly into teams and work in
              their tools, their hours, and their culture. Proxima was built to
              bridge that gap.
            </p>
          </motion.div>

          <motion.div
            {...fade(0.15)}
            style={{
              position: "relative",
              borderRadius: 24,
              overflow: "hidden",
              border: "1px solid rgba(212,175,90,0.18)",
              background:
                "linear-gradient(135deg,rgba(11,27,58,0.6),rgba(212,175,90,0.06))",
              padding: "40px 40px 44px",
            }}
          >
            <div
              style={{
                position: "absolute",
                top: -60,
                right: -40,
                width: 240,
                height: 220,
                background:
                  "radial-gradient(ellipse,rgba(212,175,90,0.14),transparent 70%)",
                pointerEvents: "none",
              }}
            />
            <blockquote style={{ margin: 0, position: "relative" }}>
              <p
                style={{
                  margin: "0 0 24px",
                  fontSize: "clamp(17px,2.2vw,21px)",
                  lineHeight: 1.55,
                  color: "#F5F7FA",
                  fontStyle: "italic",
                  fontFamily: "var(--font-newsreader), Georgia, serif",
                }}
              >
                &ldquo;Excellence, partnership, and growth — these aren&rsquo;t
                words on a wall. They&rsquo;re the way we vet, place, and
                support every professional we work with.&rdquo;
              </p>
              <footer>
                <div
                  style={{ fontWeight: 700, color: "#E6C878", fontSize: 15 }}
                >
                  Jerod Gonzales
                </div>
                <div style={{ color: "#5A6A8A", fontSize: 13.5 }}>
                  Founder &amp; CEO, Proxima Global Solutions
                </div>
              </footer>
            </blockquote>
          </motion.div>
        </div>
      </section>

      {/* Mission */}
      <section
        style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px 96px" }}
      >
        <motion.div
          {...fade()}
          style={{
            borderRadius: 24,
            border: "1px solid rgba(212,175,90,0.16)",
            background:
              "linear-gradient(135deg,rgba(11,27,58,0.5),rgba(212,175,90,0.05))",
            padding: "clamp(40px,6vw,72px) clamp(28px,5vw,64px)",
            textAlign: "center",
            position: "relative",
            overflow: "hidden",
          }}
        >
          <div
            style={{
              position: "absolute",
              top: -80,
              left: "50%",
              transform: "translateX(-50%)",
              width: 500,
              height: 300,
              background:
                "radial-gradient(ellipse,rgba(212,175,90,0.12),transparent 70%)",
              pointerEvents: "none",
            }}
          />
          <div style={{ position: "relative" }}>
            <div
              style={{
                fontSize: 12,
                letterSpacing: "0.16em",
                textTransform: "uppercase",
                color: "#D4AF5A",
                marginBottom: 18,
              }}
            >
              Our mission
            </div>
            <h2
              style={{
                margin: "0 auto",
                maxWidth: 700,
                fontSize: "clamp(24px,4vw,44px)",
                fontWeight: 700,
                letterSpacing: "-0.03em",
                color: "#F5F7FA",
                lineHeight: 1.1,
              }}
            >
              Give every business access to the talent that was once only
              available to the largest companies.
            </h2>
          </div>
        </motion.div>
      </section>

      {/* Values */}
      <section
        style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px 96px" }}
      >
        <motion.div
          {...fade()}
          style={{ marginBottom: 48, textAlign: "center" }}
        >
          <div
            style={{
              fontSize: 12,
              letterSpacing: "0.14em",
              textTransform: "uppercase",
              color: "#D4AF5A",
              marginBottom: 14,
            }}
          >
            Our values
          </div>
          <h2
            style={{
              margin: 0,
              fontSize: "clamp(28px,4vw,44px)",
              fontWeight: 700,
              letterSpacing: "-0.03em",
              color: "#F5F7FA",
            }}
          >
            How we show up.
          </h2>
        </motion.div>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
            gap: 20,
          }}
        >
          {PILLARS.map((p, i) => (
            <motion.div
              key={p.title}
              {...fade(i * 0.08)}
              style={{
                borderRadius: 20,
                border: "1px solid rgba(255,255,255,0.06)",
                background: "rgba(10,15,28,0.6)",
                padding: 32,
              }}
            >
              <div
                style={{ fontSize: 22, marginBottom: 16, color: "#D4AF5A" }}
              >
                {p.icon}
              </div>
              <h3
                style={{
                  margin: "0 0 10px",
                  fontSize: 17,
                  fontWeight: 700,
                  color: "#F5F7FA",
                }}
              >
                {p.title}
              </h3>
              <p
                style={{
                  margin: 0,
                  color: "#8A97AC",
                  lineHeight: 1.65,
                  fontSize: 14.5,
                }}
              >
                {p.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Stats */}
      <section
        style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px 96px" }}
      >
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
            gap: 16,
          }}
        >
          {METRICS.map((m, i) => (
            <motion.div
              key={m.label}
              {...fade(i * 0.08)}
              style={{
                textAlign: "center",
                padding: "44px 24px",
                borderRadius: 20,
                border: "1px solid rgba(255,255,255,0.05)",
                background: "rgba(10,15,28,0.4)",
              }}
            >
              <div
                style={{
                  fontSize: "clamp(36px,5vw,52px)",
                  fontWeight: 700,
                  color: "#E6C878",
                  letterSpacing: "-0.03em",
                  fontVariantNumeric: "tabular-nums",
                }}
              >
                {m.value}
              </div>
              <div style={{ color: "#8A97AC", fontSize: 14, marginTop: 8 }}>
                {m.label}
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Leadership */}
      <section
        style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px 96px" }}
      >
        <motion.div
          {...fade()}
          style={{ marginBottom: 40, textAlign: "center" }}
        >
          <div
            style={{
              fontSize: 12,
              letterSpacing: "0.14em",
              textTransform: "uppercase",
              color: "#D4AF5A",
              marginBottom: 14,
            }}
          >
            Leadership
          </div>
          <h2
            style={{
              margin: 0,
              fontSize: "clamp(28px,4vw,44px)",
              fontWeight: 700,
              letterSpacing: "-0.03em",
              color: "#F5F7FA",
            }}
          >
            Meet the founder.
          </h2>
        </motion.div>
        <motion.div
          {...fade(0.1)}
          style={{ maxWidth: 580, margin: "0 auto" }}
        >
          <div
            style={{
              borderRadius: 24,
              border: "1px solid rgba(212,175,90,0.18)",
              background:
                "linear-gradient(135deg,rgba(11,27,58,0.6),rgba(212,175,90,0.05))",
              padding: 40,
              display: "flex",
              gap: 24,
              alignItems: "flex-start",
            }}
          >
            <div
              style={{
                width: 72,
                height: 72,
                flexShrink: 0,
                borderRadius: 16,
                background: "linear-gradient(135deg,#0B1B3A,#1a3360)",
                border: "1.5px solid rgba(212,175,90,0.3)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 22,
                color: "#D4AF5A",
                fontWeight: 700,
                letterSpacing: "0.04em",
                fontFamily: "var(--font-jetbrains), monospace",
              }}
            >
              JG
            </div>
            <div>
              <h3
                style={{
                  margin: "0 0 4px",
                  fontSize: 20,
                  fontWeight: 700,
                  color: "#F5F7FA",
                }}
              >
                Jerod Gonzales
              </h3>
              <div
                style={{
                  color: "#D4AF5A",
                  fontSize: 13.5,
                  marginBottom: 16,
                }}
              >
                Founder &amp; CEO
              </div>
              <p
                style={{
                  margin: "0 0 18px",
                  color: "#8A97AC",
                  lineHeight: 1.65,
                  fontSize: 14.5,
                }}
              >
                Texas-based entrepreneur with deep roots in operations and
                business development. Jerod built Proxima to give growing
                businesses the same operational leverage that once required a
                Fortune 500 headcount.
              </p>
              <a
                href={CONTACT.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  textDecoration: "none",
                  color: "#D4AF5A",
                  fontSize: 13.5,
                  fontWeight: 600,
                }}
              >
                LinkedIn →
              </a>
            </div>
          </div>
        </motion.div>
      </section>

      {/* CTA */}
      <section
        style={{
          maxWidth: 1200,
          margin: "0 auto",
          padding: "0 24px 96px",
          textAlign: "center",
        }}
      >
        <motion.div {...fade()}>
          <h2
            style={{
              margin: "0 0 20px",
              fontSize: "clamp(28px,4vw,48px)",
              fontWeight: 700,
              letterSpacing: "-0.03em",
              color: "#F5F7FA",
            }}
          >
            Ready to lighten the load?
          </h2>
          <p
            style={{
              margin: "0 auto 32px",
              maxWidth: 480,
              color: "#8A97AC",
              fontSize: 17,
            }}
          >
            Book a free 20-minute call and we&rsquo;ll map out what Proxima can
            take off your plate.
          </p>
          <a
            href={BOOK_URL}
            target="_blank"
            rel="noopener noreferrer"
            style={{
              textDecoration: "none",
              display: "inline-block",
              fontWeight: 700,
              color: "#0B1B3A",
              padding: "16px 34px",
              borderRadius: 13,
              background: "linear-gradient(135deg,#E6C878,#D4AF5A)",
              boxShadow: "0 14px 40px rgba(212,175,90,0.4)",
              fontSize: 16,
            }}
          >
            Book a free consultation →
          </a>
        </motion.div>
      </section>

      <style>{`
        .about-story-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 60px;
          align-items: center;
        }
        @media (max-width: 768px) {
          .about-story-grid {
            grid-template-columns: 1fr !important;
            gap: 32px !important;
          }
        }
      `}</style>
    </PageShell>
  );
}
