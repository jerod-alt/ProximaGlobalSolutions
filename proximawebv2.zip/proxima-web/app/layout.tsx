import type { Metadata } from "next";
import { Inter, Newsreader, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const newsreader = Newsreader({
  variable: "--font-newsreader",
  subsets: ["latin"],
  weight: ["400", "500"],
  style: ["normal", "italic"],
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-jetbrains",
  subsets: ["latin"],
  weight: ["400", "500"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Proxima Global Solutions — Elite Global Talent & AI-Powered Operations",
  description:
    "Helping businesses across the US, Canada, UK, and Australia streamline operations, reduce costs, and accelerate growth through outsourcing, virtual staffing, and intelligent automation.",
  keywords: [
    "virtual assistant",
    "offshore staffing",
    "BPO",
    "business process outsourcing",
    "AI automation",
    "remote workforce",
    "accounting support",
    "HVAC coordinator",
    "solar coordinator",
  ],
  openGraph: {
    title: "Proxima Global Solutions",
    description:
      "Scale your business with elite global talent and AI-powered operations.",
    type: "website",
    url: "https://proximaglobalsolutions.com",
  },
  twitter: {
    card: "summary_large_image",
    title: "Proxima Global Solutions",
    description:
      "Scale your business with elite global talent and AI-powered operations.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${inter.variable} ${newsreader.variable} ${jetbrainsMono.variable}`}
    >
      <body>{children}</body>
    </html>
  );
}
