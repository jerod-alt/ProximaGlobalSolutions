"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import PageShell from "@/components/layout/PageShell";
import { BOOK_URL, CONTACT } from "@/lib/data";

const fade = (delay = 0) => ({
  initial: { opacity: 0, y: 20 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.5, delay },
});

const BENEFITS = [
  {
    icon: "⟶",
    title: "Work from anywhere",
    desc: "Fully remote roles with flexible hours aligned to client time zones.",
  },
  {
    icon: "◆",
    title: "Competitive pay",
    desc: "Rates that reflect your skills and experience — not where you live.",
  },
  {
    icon: "◇",
    title: "Real career growth",
    desc: "Work inside growing companies and build skills that transfer everywhere.",
  },
  {
    icon: "⬡",
    title: "Stable, long-term roles",
    desc: "Proxima places professionals in ongoing engagements, not one-off gigs.",
  },
  {
    icon: "◎",
    title: "Dedicated support",
    desc: "Our team stays involved throughout your engagement — you're never alone.",
  },
  {
    icon: "✦",
    title: "Global clients",
    desc: "Work with businesses across the US, Canada, UK, and Australia.",
  },
];

const OPENINGS = [
  {
    title: "Senior Executive Virtual Assistant",
    type: "Offshore — Remote",
    location: "LATAM / Philippines",
    range: "$900 – $1,300 / month",
    tags: ["Administrative", "Executive support", "Remote"],
    desc: "Support C-level executives with calendar management, email triage, travel coordination, and strategic admin. Requires 3+ years of EA experience.",
  },
  {
    title: "Bookkeeper / Junior Accountant",
    type: "Offshore — Remote",
    location: "LATAM / Philippines",
    range: "$800 – $1,100 / month",
    tags: ["Accounting & Finance", "Bookkeeping", "Remote"],
    desc: "Day-to-day bookkeeping, reconciliations, and payroll support for US-based clients. QuickBooks or Xero experience required.",
  },
  {
    title: "HVAC Dispatcher / Coordinator",
    type: "Offshore — Remote",
    location: "LATAM",
    range: "$900 – $1,200 / month",
    tags: ["HVAC", "Dispatch", "Field service"],
    desc: "Schedule and route field technicians, manage work orders, and handle customer communication for HVAC service companies.",
  },
  {
    title: "Solar Project Coordinator",
    type: "Offshore — Remote",
    location: "Global — Remote",
    range: "$800 – $1,200 / month",
    tags: ["Solar", "Project management", "Admin"],
    desc: "Coordinate permits, interconnection paperwork, and installation scheduling for US solar installers.",
  },
  {
    title: "Client Success Manager",
    type: "Internal — Proxima",
    location: "Remote (US preferred)",
    range: "Competitive — DOE",
    tags: ["Internal", "Client relations", "US"],
    desc: "Manage relationships with Proxima's client portfolio, monitor engagement health, and ensure both clients and professionals thrive.",
  },
];

export default function CareersPage() {
  const [applied, setApplied] = useState<string | null>(null);

  return (
    <PageShell>
      {/* Hero */}
      <section
        style={{
          maxWidth: 1200,
          margin: "0 auto",
          padding: "96px 24px 80px",
          textAlign: "center",
        }}
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div
            style={{
              fontSize: 12,
              letterSpacing: "0.18em",
              textTransform: "uppercase",
              color: "#D4AF5A",
              marginBottom: 18,
            }}
          >
            Careers at Proxima
          </div>
          <h1
            style={{
              margin: 0,
              fontSize: "clamp(40px,7vw,72px)",
              fontWeight: 700,
              letterSpacing: "-0.03em",
              color: "#F5F7FA",
              lineHeight: 1.06,
              fontFamily: "var(--font-newsreader), Georgia, serif",
            }}
          >
            Grow your career
            <br />
            without limits.
          </h1>
          <p
            style={{
              margin: "22px auto 0",
              maxWidth: 520,
              color: "#8A97AC",
              fontSize: 17,
              lineHeight: 1.65,
            }}
          >
            Proxima places talented professionals inside great businesses
            worldwide. We&rsquo;re always looking for exceptional people who
            are ready to work at a higher level.
          </p>
        </motion.div>
      </section>

      {/* Why join */}
      <section
        style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px 96px" }}
      >
        <motion.div
          {...fade()}
          style={{ marginBottom: 48, textAlign: "center" }}
        >
          <div
            style={{
              fontSize: 12,
              letterSpacing: "0.14em",
              textTransform: "uppercase",
              color: "#D4AF5A",
              marginBottom: 14,
            }}
          >
            Why Proxima
          </div>
          <h2
            style={{
              margin: 0,
              fontSize: "clamp(26px,4vw,42px)",
              fontWeight: 700,
              letterSpacing: "-0.03em",
              color: "#F5F7FA",
            }}
          >
            What you get with us.
          </h2>
        </motion.div>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            gap: 20,
          }}
        >
          {BENEFITS.map((b, i) => (
            <motion.div
              key={b.title}
              {...fade(i * 0.06)}
              style={{
                borderRadius: 20,
                border: "1px solid rgba(255,255,255,0.06)",
                background: "rgba(10,15,28,0.6)",
                padding: 28,
                display: "flex",
                gap: 18,
                alignItems: "flex-start",
              }}
            >
              <div
                style={{
                  width: 40,
                  height: 40,
                  flexShrink: 0,
                  borderRadius: 12,
                  background: "rgba(212,175,90,0.08)",
                  border: "1px solid rgba(212,175,90,0.16)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 16,
                  color: "#D4AF5A",
                }}
              >
                {b.icon}
              </div>
              <div>
                <h3
                  style={{
                    margin: "0 0 7px",
                    fontSize: 16,
                    fontWeight: 700,
                    color: "#F5F7FA",
                  }}
                >
                  {b.title}
                </h3>
                <p
                  style={{
                    margin: 0,
                    color: "#8A97AC",
                    lineHeight: 1.6,
                    fontSize: 14,
                  }}
                >
                  {b.desc}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Open positions */}
      <section
        style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px 96px" }}
      >
        <motion.div
          {...fade()}
          style={{ marginBottom: 40 }}
        >
          <div
            style={{
              fontSize: 12,
              letterSpacing: "0.14em",
              textTransform: "uppercase",
              color: "#D4AF5A",
              marginBottom: 14,
            }}
          >
            Open positions
          </div>
          <h2
            style={{
              margin: "0 0 8px",
              fontSize: "clamp(26px,4vw,42px)",
              fontWeight: 700,
              letterSpacing: "-0.03em",
              color: "#F5F7FA",
            }}
          >
            Roles available now.
          </h2>
          <p style={{ margin: 0, color: "#8A97AC", fontSize: 15 }}>
            All positions are fully remote. Rates shown are monthly.
          </p>
        </motion.div>

        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {OPENINGS.map((job, i) => (
            <motion.div
              key={job.title}
              {...fade(i * 0.06)}
              style={{
                borderRadius: 20,
                border: "1px solid rgba(255,255,255,0.07)",
                background: "rgba(10,15,28,0.6)",
                padding: "28px 32px",
              }}
            >
              <div className="job-card-inner">
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 12,
                      flexWrap: "wrap",
                      marginBottom: 6,
                    }}
                  >
                    <h3
                      style={{
                        margin: 0,
                        fontSize: 18,
                        fontWeight: 700,
                        color: "#F5F7FA",
                      }}
                    >
                      {job.title}
                    </h3>
                    {job.type.includes("Internal") && (
                      <span
                        style={{
                          fontSize: 11,
                          fontWeight: 600,
                          color: "#D4AF5A",
                          background: "rgba(212,175,90,0.1)",
                          border: "1px solid rgba(212,175,90,0.2)",
                          borderRadius: 6,
                          padding: "2px 8px",
                          letterSpacing: "0.04em",
                          textTransform: "uppercase",
                        }}
                      >
                        Internal
                      </span>
                    )}
                  </div>

                  <div
                    style={{
                      display: "flex",
                      gap: 16,
                      flexWrap: "wrap",
                      marginBottom: 12,
                    }}
                  >
                    <span
                      style={{
                        fontSize: 13.5,
                        color: "#5A6A8A",
                        display: "flex",
                        alignItems: "center",
                        gap: 5,
                      }}
                    >
                      <span style={{ color: "#3A4A62" }}>◎</span> {job.location}
                    </span>
                    <span
                      style={{
                        fontSize: 13.5,
                        color: "#C9B583",
                        fontWeight: 600,
                        fontFamily: "var(--font-jetbrains), monospace",
                      }}
                    >
                      {job.range}
                    </span>
                  </div>

                  <p
                    style={{
                      margin: "0 0 14px",
                      color: "#8A97AC",
                      fontSize: 14.5,
                      lineHeight: 1.6,
                      maxWidth: 640,
                    }}
                  >
                    {job.desc}
                  </p>

                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    {job.tags.map((tag) => (
                      <span
                        key={tag}
                        style={{
                          fontSize: 12,
                          color: "#8A97AC",
                          background: "rgba(255,255,255,0.04)",
                          border: "1px solid rgba(255,255,255,0.08)",
                          borderRadius: 6,
                          padding: "3px 9px",
                        }}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                <div style={{ flexShrink: 0, paddingTop: 4 }}>
                  {applied === job.title ? (
                    <div
                      style={{
                        fontSize: 14,
                        color: "#4CAF7D",
                        fontWeight: 600,
                        display: "flex",
                        alignItems: "center",
                        gap: 6,
                      }}
                    >
                      ✓ Applied
                    </div>
                  ) : (
                    <a
                      href={`mailto:${CONTACT.email}?subject=Application: ${encodeURIComponent(job.title)}&body=Hi Jerod,%0A%0AI'm interested in the ${encodeURIComponent(job.title)} role at Proxima Global Solutions.%0A%0AAbout me:%0A`}
                      onClick={() => setApplied(job.title)}
                      style={{
                        display: "inline-block",
                        textDecoration: "none",
                        fontWeight: 700,
                        color: "#0B1B3A",
                        padding: "11px 22px",
                        borderRadius: 11,
                        background: "linear-gradient(135deg,#E6C878,#D4AF5A)",
                        fontSize: 14,
                        whiteSpace: "nowrap",
                        boxShadow: "0 6px 20px rgba(212,175,90,0.25)",
                      }}
                    >
                      Apply now →
                    </a>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.p
          {...fade(0.2)}
          style={{
            marginTop: 28,
            textAlign: "center",
            color: "#5A6A8A",
            fontSize: 14,
          }}
        >
          Don&rsquo;t see your role?{" "}
          <a
            href={`mailto:${CONTACT.email}?subject=General Application — Proxima&body=Hi Jerod,%0A%0AI'd like to introduce myself and explore whether my skills could be a fit for Proxima.%0A%0A`}
            style={{ color: "#D4AF5A", textDecoration: "none" }}
          >
            Send us a general application →
          </a>
        </motion.p>
      </section>

      {/* CTA */}
      <section
        style={{
          maxWidth: 1200,
          margin: "0 auto",
          padding: "0 24px 96px",
          textAlign: "center",
        }}
      >
        <motion.div
          {...fade()}
          style={{
            borderRadius: 24,
            border: "1px solid rgba(212,175,90,0.18)",
            background:
              "linear-gradient(135deg,rgba(11,27,58,0.6),rgba(212,175,90,0.06))",
            padding: "clamp(40px,6vw,70px) clamp(28px,5vw,60px)",
            position: "relative",
            overflow: "hidden",
          }}
        >
          <div
            style={{
              position: "absolute",
              top: -80,
              left: "50%",
              transform: "translateX(-50%)",
              width: 500,
              height: 300,
              background:
                "radial-gradient(ellipse,rgba(212,175,90,0.13),transparent 70%)",
              pointerEvents: "none",
            }}
          />
          <div style={{ position: "relative" }}>
            <h2
              style={{
                margin: "0 0 16px",
                fontSize: "clamp(26px,4vw,44px)",
                fontWeight: 700,
                letterSpacing: "-0.03em",
                color: "#F5F7FA",
              }}
            >
              Have questions before applying?
            </h2>
            <p
              style={{
                margin: "0 auto 28px",
                maxWidth: 460,
                color: "#8A97AC",
                fontSize: 16,
              }}
            >
              Book a quick call with our team and we&rsquo;ll walk you through
              how Proxima works and what to expect.
            </p>
            <div
              style={{
                display: "flex",
                gap: 12,
                justifyContent: "center",
                flexWrap: "wrap",
              }}
            >
              <a
                href={BOOK_URL}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  textDecoration: "none",
                  fontWeight: 700,
                  color: "#0B1B3A",
                  padding: "14px 28px",
                  borderRadius: 12,
                  background: "linear-gradient(135deg,#E6C878,#D4AF5A)",
                  boxShadow: "0 12px 34px rgba(212,175,90,0.35)",
                  fontSize: 15,
                }}
              >
                Book a call →
              </a>
              <a
                href={`mailto:${CONTACT.email}`}
                style={{
                  textDecoration: "none",
                  fontWeight: 600,
                  color: "#E2E8F0",
                  padding: "14px 28px",
                  borderRadius: 12,
                  background: "rgba(255,255,255,0.06)",
                  border: "1px solid rgba(255,255,255,0.12)",
                  fontSize: 15,
                }}
              >
                Email us
              </a>
            </div>
          </div>
        </motion.div>
      </section>

      <style>{`
        .job-card-inner {
          display: flex;
          gap: 24px;
          align-items: flex-start;
        }
        @media (max-width: 640px) {
          .job-card-inner {
            flex-direction: column !important;
          }
        }
      `}</style>
    </PageShell>
  );
}
