"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import PageShell from "@/components/layout/PageShell";
import { BOOK_URL, CONTACT, SERVICES } from "@/lib/data";

const SERVICE_OPTIONS = [
  ...new Set(SERVICES.map((s) => s.category)),
].sort();

const fade = (delay = 0) => ({
  initial: { opacity: 0, y: 20 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.5, delay },
});

type FormState = "idle" | "sending" | "sent";

export default function ContactPage() {
  const [formState, setFormState] = useState<FormState>("idle");
  const [values, setValues] = useState({
    name: "",
    email: "",
    company: "",
    service: "",
    message: "",
  });

  const set = (k: keyof typeof values) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setValues((v) => ({ ...v, [k]: e.target.value }));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormState("sending");
    setTimeout(() => setFormState("sent"), 1200);
  };

  const inputStyle: React.CSSProperties = {
    width: "100%",
    background: "rgba(7,10,20,0.6)",
    border: "1px solid rgba(255,255,255,0.1)",
    borderRadius: 12,
    padding: "13px 15px",
    color: "#F5F7FA",
    font: "inherit",
    fontSize: 15,
    outline: "none",
    transition: "border-color 0.2s",
    boxSizing: "border-box",
  };

  return (
    <PageShell>
      {/* Hero */}
      <section
        style={{
          maxWidth: 1200,
          margin: "0 auto",
          padding: "96px 24px 60px",
          textAlign: "center",
        }}
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div
            style={{
              fontSize: 12,
              letterSpacing: "0.18em",
              textTransform: "uppercase",
              color: "#D4AF5A",
              marginBottom: 18,
            }}
          >
            Get in touch
          </div>
          <h1
            style={{
              margin: 0,
              fontSize: "clamp(38px,6vw,64px)",
              fontWeight: 700,
              letterSpacing: "-0.03em",
              color: "#F5F7FA",
              lineHeight: 1.06,
              fontFamily: "var(--font-newsreader), Georgia, serif",
            }}
          >
            Let&rsquo;s talk about
            <br />
            your team.
          </h1>
          <p
            style={{
              margin: "20px auto 0",
              maxWidth: 480,
              color: "#8A97AC",
              fontSize: 17,
              lineHeight: 1.65,
            }}
          >
            Book a free 20-minute call or drop us a message and we&rsquo;ll
            come back to you within one business day.
          </p>
        </motion.div>
      </section>

      {/* Two-col layout */}
      <section
        style={{
          maxWidth: 1200,
          margin: "0 auto",
          padding: "0 24px 96px",
        }}
      >
        <div className="contact-grid">
          {/* Form */}
          <motion.div {...fade()}>
            {formState === "sent" ? (
              <div
                style={{
                  borderRadius: 22,
                  border: "1px solid rgba(212,175,90,0.22)",
                  background:
                    "linear-gradient(135deg,rgba(11,27,58,0.6),rgba(212,175,90,0.06))",
                  padding: "60px 40px",
                  textAlign: "center",
                }}
              >
                <div
                  style={{
                    width: 56,
                    height: 56,
                    borderRadius: "50%",
                    background: "rgba(76,175,125,0.15)",
                    border: "1px solid rgba(76,175,125,0.3)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    margin: "0 auto 20px",
                    fontSize: 22,
                    color: "#4CAF7D",
                  }}
                >
                  ✓
                </div>
                <h2
                  style={{
                    margin: "0 0 12px",
                    fontSize: 24,
                    fontWeight: 700,
                    color: "#F5F7FA",
                  }}
                >
                  Message received.
                </h2>
                <p style={{ margin: 0, color: "#8A97AC", fontSize: 15 }}>
                  We&rsquo;ll be in touch within one business day. You can also{" "}
                  <a
                    href={BOOK_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{ color: "#D4AF5A" }}
                  >
                    book a call directly
                  </a>{" "}
                  if you&rsquo;d prefer.
                </p>
              </div>
            ) : (
              <form
                onSubmit={handleSubmit}
                style={{
                  borderRadius: 22,
                  border: "1px solid rgba(255,255,255,0.07)",
                  background: "rgba(10,15,28,0.6)",
                  padding: "clamp(28px,4vw,44px)",
                  display: "flex",
                  flexDirection: "column",
                  gap: 18,
                }}
              >
                <h2
                  style={{
                    margin: "0 0 4px",
                    fontSize: 20,
                    fontWeight: 700,
                    color: "#F5F7FA",
                  }}
                >
                  Send us a message
                </h2>

                <div className="contact-name-row">
                  <div>
                    <label
                      style={{
                        display: "block",
                        fontSize: 13,
                        color: "#C3CCDA",
                        marginBottom: 7,
                        fontWeight: 500,
                      }}
                    >
                      Your name
                    </label>
                    <input
                      type="text"
                      required
                      value={values.name}
                      onChange={set("name")}
                      placeholder="Jane Smith"
                      style={inputStyle}
                      onFocus={(e) =>
                        ((e.target as HTMLInputElement).style.borderColor =
                          "rgba(212,175,90,0.5)")
                      }
                      onBlur={(e) =>
                        ((e.target as HTMLInputElement).style.borderColor =
                          "rgba(255,255,255,0.1)")
                      }
                    />
                  </div>
                  <div>
                    <label
                      style={{
                        display: "block",
                        fontSize: 13,
                        color: "#C3CCDA",
                        marginBottom: 7,
                        fontWeight: 500,
                      }}
                    >
                      Company
                    </label>
                    <input
                      type="text"
                      value={values.company}
                      onChange={set("company")}
                      placeholder="Acme Corp"
                      style={inputStyle}
                      onFocus={(e) =>
                        ((e.target as HTMLInputElement).style.borderColor =
                          "rgba(212,175,90,0.5)")
                      }
                      onBlur={(e) =>
                        ((e.target as HTMLInputElement).style.borderColor =
                          "rgba(255,255,255,0.1)")
                      }
                    />
                  </div>
                </div>

                <div>
                  <label
                    style={{
                      display: "block",
                      fontSize: 13,
                      color: "#C3CCDA",
                      marginBottom: 7,
                      fontWeight: 500,
                    }}
                  >
                    Email address
                  </label>
                  <input
                    type="email"
                    required
                    value={values.email}
                    onChange={set("email")}
                    placeholder="you@company.com"
                    style={inputStyle}
                    onFocus={(e) =>
                      ((e.target as HTMLInputElement).style.borderColor =
                        "rgba(212,175,90,0.5)")
                    }
                    onBlur={(e) =>
                      ((e.target as HTMLInputElement).style.borderColor =
                        "rgba(255,255,255,0.1)")
                    }
                  />
                </div>

                <div>
                  <label
                    style={{
                      display: "block",
                      fontSize: 13,
                      color: "#C3CCDA",
                      marginBottom: 7,
                      fontWeight: 500,
                    }}
                  >
                    Service area of interest
                  </label>
                  <select
                    value={values.service}
                    onChange={set("service")}
                    style={{
                      ...inputStyle,
                      appearance: "none",
                      backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%238A97AC' stroke-width='1.5' fill='none' stroke-linecap='round'/%3E%3C/svg%3E")`,
                      backgroundRepeat: "no-repeat",
                      backgroundPosition: "right 14px center",
                      paddingRight: 40,
                      cursor: "pointer",
                    }}
                    onFocus={(e) =>
                      ((e.target as HTMLSelectElement).style.borderColor =
                        "rgba(212,175,90,0.5)")
                    }
                    onBlur={(e) =>
                      ((e.target as HTMLSelectElement).style.borderColor =
                        "rgba(255,255,255,0.1)")
                    }
                  >
                    <option value="" style={{ background: "#070A14" }}>
                      Select a category…
                    </option>
                    {SERVICE_OPTIONS.map((opt) => (
                      <option
                        key={opt}
                        value={opt}
                        style={{ background: "#070A14" }}
                      >
                        {opt}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label
                    style={{
                      display: "block",
                      fontSize: 13,
                      color: "#C3CCDA",
                      marginBottom: 7,
                      fontWeight: 500,
                    }}
                  >
                    Tell us about your needs
                  </label>
                  <textarea
                    required
                    rows={5}
                    value={values.message}
                    onChange={set("message")}
                    placeholder="What does your team need help with? Any context about your business or current setup is useful."
                    style={{
                      ...inputStyle,
                      resize: "vertical",
                      minHeight: 120,
                    }}
                    onFocus={(e) =>
                      ((e.target as HTMLTextAreaElement).style.borderColor =
                        "rgba(212,175,90,0.5)")
                    }
                    onBlur={(e) =>
                      ((e.target as HTMLTextAreaElement).style.borderColor =
                        "rgba(255,255,255,0.1)")
                    }
                  />
                </div>

                <button
                  type="submit"
                  disabled={formState === "sending"}
                  style={{
                    background: "linear-gradient(135deg,#E6C878,#D4AF5A)",
                    border: "none",
                    color: "#0B1B3A",
                    font: "inherit",
                    fontWeight: 700,
                    fontSize: 15,
                    padding: "14px 28px",
                    borderRadius: 12,
                    cursor: formState === "sending" ? "not-allowed" : "pointer",
                    opacity: formState === "sending" ? 0.7 : 1,
                    transition: "opacity 0.2s, transform 0.2s",
                    alignSelf: "flex-start",
                    boxShadow: "0 10px 30px rgba(212,175,90,0.3)",
                  }}
                >
                  {formState === "sending" ? "Sending…" : "Send message →"}
                </button>
              </form>
            )}
          </motion.div>

          {/* Info */}
          <motion.div
            {...fade(0.15)}
            style={{ display: "flex", flexDirection: "column", gap: 20 }}
          >
            {/* Calendly CTA */}
            <div
              style={{
                borderRadius: 22,
                border: "1px solid rgba(212,175,90,0.22)",
                background:
                  "linear-gradient(135deg,rgba(11,27,58,0.6),rgba(212,175,90,0.07))",
                padding: 32,
                position: "relative",
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  position: "absolute",
                  top: -50,
                  right: -30,
                  width: 200,
                  height: 180,
                  background:
                    "radial-gradient(ellipse,rgba(212,175,90,0.16),transparent 70%)",
                  pointerEvents: "none",
                }}
              />
              <div style={{ position: "relative" }}>
                <div
                  style={{
                    fontSize: 12,
                    letterSpacing: "0.14em",
                    textTransform: "uppercase",
                    color: "#D4AF5A",
                    marginBottom: 12,
                  }}
                >
                  Prefer a call?
                </div>
                <h3
                  style={{
                    margin: "0 0 10px",
                    fontSize: 20,
                    fontWeight: 700,
                    color: "#F5F7FA",
                  }}
                >
                  Book a free 20-minute intro
                </h3>
                <p
                  style={{
                    margin: "0 0 22px",
                    color: "#8A97AC",
                    fontSize: 14.5,
                    lineHeight: 1.6,
                  }}
                >
                  We&rsquo;ll learn about your team and explore whether
                  Proxima is the right fit — no pressure.
                </p>
                <a
                  href={BOOK_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{
                    textDecoration: "none",
                    display: "inline-block",
                    fontWeight: 700,
                    color: "#0B1B3A",
                    padding: "12px 22px",
                    borderRadius: 11,
                    background: "linear-gradient(135deg,#E6C878,#D4AF5A)",
                    fontSize: 14,
                    boxShadow: "0 8px 24px rgba(212,175,90,0.3)",
                  }}
                >
                  Book on Calendly →
                </a>
              </div>
            </div>

            {/* Contact details */}
            <div
              style={{
                borderRadius: 22,
                border: "1px solid rgba(255,255,255,0.07)",
                background: "rgba(10,15,28,0.6)",
                padding: 32,
              }}
            >
              <h3
                style={{
                  margin: "0 0 22px",
                  fontSize: 16,
                  fontWeight: 700,
                  color: "#F5F7FA",
                }}
              >
                Contact details
              </h3>
              <div
                style={{ display: "flex", flexDirection: "column", gap: 16 }}
              >
                <ContactRow
                  icon="✉"
                  label="Email"
                  value={CONTACT.email}
                  href={`mailto:${CONTACT.email}`}
                />
                <ContactRow
                  icon="☎"
                  label="Phone"
                  value={CONTACT.phone}
                  href={`tel:${CONTACT.phone.replace(/\D/g, "")}`}
                />
                <ContactRow
                  icon="in"
                  label="LinkedIn"
                  value="Jerod Gonzales"
                  href={CONTACT.linkedin}
                  external
                />
              </div>
            </div>

            {/* Response time */}
            <div
              style={{
                borderRadius: 18,
                border: "1px solid rgba(255,255,255,0.05)",
                background: "rgba(10,15,28,0.3)",
                padding: "20px 24px",
                display: "flex",
                gap: 16,
                alignItems: "flex-start",
              }}
            >
              <span
                style={{
                  width: 36,
                  height: 36,
                  borderRadius: 10,
                  background: "rgba(76,175,125,0.12)",
                  border: "1px solid rgba(76,175,125,0.2)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 14,
                  color: "#4CAF7D",
                  flexShrink: 0,
                }}
              >
                ✓
              </span>
              <div>
                <div
                  style={{
                    fontWeight: 600,
                    color: "#C3CCDA",
                    fontSize: 14,
                    marginBottom: 3,
                  }}
                >
                  We respond fast
                </div>
                <div style={{ color: "#5A6A8A", fontSize: 13.5 }}>
                  Expect a reply within one business day. For urgent
                  inquiries, call or book directly.
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <style>{`
        .contact-grid {
          display: grid;
          grid-template-columns: 1.3fr 1fr;
          gap: 40px;
          align-items: start;
        }
        .contact-name-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 14px;
        }
        @media (max-width: 900px) {
          .contact-grid {
            grid-template-columns: 1fr !important;
          }
        }
        @media (max-width: 520px) {
          .contact-name-row {
            grid-template-columns: 1fr !important;
          }
        }
        option { background: #070A14; }
      `}</style>
    </PageShell>
  );
}

function ContactRow({
  icon,
  label,
  value,
  href,
  external,
}: {
  icon: string;
  label: string;
  value: string;
  href: string;
  external?: boolean;
}) {
  return (
    <div style={{ display: "flex", gap: 14, alignItems: "center" }}>
      <div
        style={{
          width: 38,
          height: 38,
          borderRadius: 10,
          background: "rgba(212,175,90,0.08)",
          border: "1px solid rgba(212,175,90,0.16)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 13,
          color: "#D4AF5A",
          flexShrink: 0,
          fontFamily: "var(--font-jetbrains), monospace",
          fontWeight: 500,
        }}
      >
        {icon}
      </div>
      <div>
        <div style={{ fontSize: 11.5, color: "#5A6A8A", marginBottom: 2 }}>
          {label}
        </div>
        <a
          href={href}
          target={external ? "_blank" : undefined}
          rel={external ? "noopener noreferrer" : undefined}
          style={{
            textDecoration: "none",
            color: "#C3CCDA",
            fontSize: 14.5,
            fontWeight: 500,
            transition: "color 0.15s",
          }}
          onMouseEnter={(e) =>
            ((e.currentTarget as HTMLAnchorElement).style.color = "#E6C878")
          }
          onMouseLeave={(e) =>
            ((e.currentTarget as HTMLAnchorElement).style.color = "#C3CCDA")
          }
        >
          {value}
        </a>
      </div>
    </div>
  );
}
